using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;

namespace ClassroomInstaller
{
    /// <summary>
    /// Установщик системы управления компьютерным классом.
    /// Копирует файлы, регистрирует службу, настраивает автозапуск.
    /// Требует запуска от имени Администратора.
    /// </summary>
    class Program
    {
        // Пути установки
        private const string BaseFolder = @"C:\Program Files\ClassroomSystem";
        private const string BinFolder = BaseFolder + @"\bin";
        private const string LogFolder = BaseFolder + @"\logs";
        private const string BackupFolder = @"C:\ProgramData\Microsoft\Diagnostics";
        private const string ServiceName = "ClassroomGuardian";
        private const string ServiceExe = "ClassroomGuardian.exe";
        private const string LoginExe = "ClassroomLogin.exe";
        private const string InstallerExe = "ClassroomInstaller.exe";

        // Настройка hosts
        private const string HostsEntry = "172.23.9.151\tMySQL-8.4";
        private const string HostsMarker = "MySQL-8.4";

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // Баннер
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine();
            Console.WriteLine("  ╔═══════════════════════════════════════════════╗");
            Console.WriteLine("  ║     УСТАНОВКА СИСТЕМЫ КОМПЬЮТЕРНОГО КЛАССА    ║");
            Console.WriteLine("  ╚═══════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();

            // Проверка прав администратора
            if (!IsAdministrator())
            {
                WriteError("Требуются права Администратора!");
                WriteError("Запустите правой кнопкой → Запуск от имени администратора");
                Console.WriteLine();
                Console.Write("  Нажмите любую клавишу...");
                Console.ReadKey();
                return;
            }

            WriteOk("Права администратора подтверждены");
            Console.WriteLine();

            // 1. Остановка всех связанных процессов и службы
            WriteStep("Остановка всех процессов и службы...");
            CleanStop();

            // 2. Очистка старых файлов
            WriteStep("Очистка старых файлов...");
            CleanOldFiles();

            // 3. Создание директорий
            WriteStep("Создание директорий...");
            CreateDirectories();

            // 4. Копирование файлов
            WriteStep("Копирование файлов...");
            CopyFiles();

            // 5. Скрываем резервную папку
            WriteStep("Скрытие резервной копии...");
            HideBackupFolder();

            // 6. Регистрация службы
            WriteStep("Регистрация службы ClassroomGuardian...");
            RegisterService();

            // 7. Запуск службы
            WriteStep("Запуск службы...");
            StartService();

            // 8. Автозапуск ClassroomLogin
            WriteStep("Настройка автозапуска ClassroomLogin...");
            SetupAutostart();

            // 9. Настройка hosts (MySQL)
            WriteStep("Настройка hosts (MySQL-8.4)...");
            ConfigureHosts();

            // 10. Скрипт удаления
            WriteStep("Создание скрипта удаления...");
            CreateUninstallScript();

            // Итог
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  ╔═══════════════════════════════════════════════╗");
            Console.WriteLine("  ║           УСТАНОВКА ЗАВЕРШЕНА УСПЕШНО         ║");
            Console.WriteLine("  ╚═══════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine($"  Программы:      {BinFolder}");
            Console.WriteLine($"  Логи:           {LogFolder}");
            Console.WriteLine($"  Служба:         {ServiceName} (автозапуск)");
            Console.WriteLine($"  Автозапуск:     Реестр + Планировщик задач");
            Console.WriteLine($"  Hosts:          {HostsEntry}");
            Console.WriteLine($"  Удаление:       {BaseFolder}\\uninstall.bat");
            Console.WriteLine();
            Console.Write("  Нажмите любую клавишу...");
            Console.ReadKey();
        }

        /// <summary>
        /// Полная остановка: служба + все связанные процессы
        /// </summary>
        static void CleanStop()
        {
            // Служба
            RunCmd("net stop ClassroomGuardian", silent: true);
            Thread.Sleep(500);

            // Убиваем все связанные процессы
            string[] processes = { "ClassroomGuardian", "ClassroomLogin", "SessionWatcher" };
            foreach (var proc in processes)
            {
                RunCmd($"taskkill /f /im {proc}.exe", silent: true);
            }

            Thread.Sleep(1000);
            WriteOk("Все процессы остановлены");
        }

        /// <summary>
        /// Очистка старых файлов в bin и скрытой папке
        /// </summary>
        static void CleanOldFiles()
        {
            int cleaned = 0;

            // Очистка bin
            if (Directory.Exists(BinFolder))
            {
                try
                {
                    foreach (var f in Directory.GetFiles(BinFolder))
                    {
                        try { File.Delete(f); cleaned++; }
                        catch { }
                    }
                    WriteOk($"bin: удалено {cleaned} файлов");
                }
                catch (Exception ex) { WriteError($"Очистка bin: {ex.Message}"); }
            }

            // Очистка скрытой папки (снимаем атрибуты → удаляем файлы)
            if (Directory.Exists(BackupFolder))
            {
                try
                {
                    // Снимаем Hidden/System с папки
                    var dirInfo = new DirectoryInfo(BackupFolder);
                    dirInfo.Attributes = FileAttributes.Directory;

                    int backupCleaned = 0;
                    foreach (var f in Directory.GetFiles(BackupFolder))
                    {
                        try
                        {
                            // Снимаем Hidden с файла
                            File.SetAttributes(f, FileAttributes.Normal);
                            File.Delete(f);
                            backupCleaned++;
                        }
                        catch { }
                    }
                    WriteOk($"Резервная копия: удалено {backupCleaned} файлов");
                }
                catch (Exception ex) { WriteError($"Очистка резерва: {ex.Message}"); }
            }
            else
            {
                WriteOk("Старых файлов нет");
            }
        }

        static bool IsAdministrator()
        {
            using (var identity = WindowsIdentity.GetCurrent())
            {
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        /// <summary>
        /// Создание всех директорий
        /// </summary>
        static void CreateDirectories()
        {
            try
            {
                // Основные папки
                Directory.CreateDirectory(BinFolder);
                WriteOk($"Программы: {BinFolder}");

                Directory.CreateDirectory(LogFolder);
                WriteOk($"Логи: {LogFolder}");

                // Скрытая резервная папка — создаём БЕЗ атрибутов (скроем после копирования)
                Directory.CreateDirectory(BackupFolder);
                // Снимаем Hidden/System если остались от прошлой установки
                var dirInfo = new DirectoryInfo(BackupFolder);
                dirInfo.Attributes = FileAttributes.Directory;
                WriteOk("Резервная копия: подготовлена");
            }
            catch (Exception ex)
            {
                WriteError($"Ошибка создания директорий: {ex.Message}");
            }
        }

        /// <summary>
        /// Копирование файлов в bin + скрытый бэкап
        /// </summary>
        static void CopyFiles()
        {
            string sourceDir = AppDomain.CurrentDomain.BaseDirectory;
            int copied = 0;
            int errors = 0;

            var patterns = new[] { "*.exe", "*.exe.config", "*.dll", "*.pdb" };
            var filesToCopy = patterns
                .SelectMany(p => Directory.GetFiles(sourceDir, p, SearchOption.TopDirectoryOnly))
                .Distinct()
                .ToList();

            foreach (var filePath in filesToCopy)
            {
                string fileName = Path.GetFileName(filePath);

                // Пропускаем сам инсталлятор
                if (fileName.Equals(InstallerExe, StringComparison.OrdinalIgnoreCase) ||
                    fileName.Equals(InstallerExe + ".config", StringComparison.OrdinalIgnoreCase))
                    continue;

                bool ok = true;

                // Копируем в bin
                try
                {
                    File.Copy(filePath, Path.Combine(BinFolder, fileName), true);
                }
                catch (Exception ex)
                {
                    WriteError($"  {fileName} → bin: {ex.Message}");
                    errors++;
                    ok = false;
                }

                // Копируем в бэкап (скроем позже)
                try
                {
                    string destBackup = Path.Combine(BackupFolder, fileName);
                    File.Copy(filePath, destBackup, true);
                }
                catch (Exception ex)
                {
                    WriteError($"  {fileName} → резерв: {ex.Message}");
                    errors++;
                    ok = false;
                }

                if (ok)
                {
                    WriteOk($"  {fileName}");
                    copied++;
                }
            }

            Console.WriteLine();
            WriteOk($"Скопировано: {copied}" + (errors > 0 ? $", ошибок: {errors}" : ""));
        }

        /// <summary>
        /// Регистрация Windows-службы
        /// </summary>
        static void RegisterService()
        {
            // Удаляем старую если есть
            RunCmd($"sc delete {ServiceName}", silent: true);
            Thread.Sleep(500);

            // Служба запускается из bin
            string binPath = Path.Combine(BinFolder, ServiceExe);

            string result = RunCmd($"sc create {ServiceName} binPath= \"{binPath}\" start= auto");
            if (result.Contains("SUCCESS") || result.Contains("[SC]"))
                WriteOk("Служба зарегистрирована");
            else
                WriteError($"Регистрация: {result.Trim()}");

            RunCmd($"sc description {ServiceName} \"Служба управления компьютерным классом\"");
            RunCmd($"sc failure {ServiceName} reset= 86400 actions= restart/60000/restart/60000/restart/60000");
            WriteOk("Автовосстановление при сбоях настроено");
        }

        static void StartService()
        {
            string result = RunCmd($"net start {ServiceName}");
            if (result.Contains("успешно") || result.Contains("successfully") || result.Contains("started"))
                WriteOk("Служба запущена");
            else
                WriteError($"Запуск: {result.Trim()}");
        }

        /// <summary>
        /// Автозапуск ClassroomLogin: реестр + планировщик
        /// </summary>
        static void SetupAutostart()
        {
            string loginPath = Path.Combine(BinFolder, LoginExe);

            // Реестр
            string regResult = RunCmd($"reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\" /v ClassroomLogin /t REG_SZ /d \"\\\"{loginPath}\\\"\" /f");
            if (regResult.Contains("успешно") || regResult.Contains("successfully") || regResult.Contains("completed"))
                WriteOk("Автозапуск: реестр");
            else
                WriteError($"Реестр: {regResult.Trim()}");

            // Планировщик
            string schtaskResult = RunCmd($"schtasks /create /tn \"ClassroomLoginStartup\" /tr \"\\\"{loginPath}\\\"\" /sc onlogon /rl highest /f");
            if (schtaskResult.Contains("SUCCESS") || schtaskResult.Contains("успешно") || schtaskResult.Contains("created"))
                WriteOk("Автозапуск: планировщик задач");
            else
                WriteError($"Планировщик: {schtaskResult.Trim()}");
        }

        /// <summary>
        /// Добавление записи в hosts для MySQL
        /// </summary>
        static void ConfigureHosts()
        {
            string hostsPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System),
                @"drivers\etc\hosts");

            try
            {
                // Читаем текущий hosts
                string content = File.Exists(hostsPath)
                    ? File.ReadAllText(hostsPath, Encoding.UTF8)
                    : "";

                // Проверяем, нет ли уже такой записи
                if (content.Contains(HostsMarker))
                {
                    WriteOk("Запись MySQL-8.4 уже существует в hosts");
                    return;
                }

                // Добавляем запись
                using (var sw = File.AppendText(hostsPath))
                {
                    if (!content.EndsWith("\n") && !content.EndsWith(Environment.NewLine))
                        sw.WriteLine(); // новая строка если файл не заканчивается на \n
                    sw.WriteLine(HostsEntry);
                }

                WriteOk($"hosts: добавлено {HostsEntry}");
            }
            catch (Exception ex)
            {
                WriteError($"hosts: {ex.Message}");
            }
        }

        /// <summary>
        /// Скрипт удаления (OEM-866 для cmd)
        /// </summary>
        static void CreateUninstallScript()
        {
            string batContent =
                "@echo off\r\n" +
                "echo.\r\n" +
                "echo ========================================\r\n" +
                "echo   УДАЛЕНИЕ СИСТЕМЫ КОМПЬЮТЕРНОГО КЛАССА\r\n" +
                "echo ========================================\r\n" +
                "echo.\r\n" +
                "net stop ClassroomGuardian 2>nul\r\n" +
                "sc delete ClassroomGuardian 2>nul\r\n" +
                "schtasks /delete /tn \"ClassroomLoginStartup\" /f 2>nul\r\n" +
                "reg delete \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\" /v ClassroomLogin /f 2>nul\r\n" +
                $"attrib -h -s \"{BackupFolder}\" 2>nul\r\n" +
                $"rmdir /s /q \"{BackupFolder}\" 2>nul\r\n" +
                "powershell -Command \"(Get-Content '%SystemRoot%\\System32\\drivers\\etc\\hosts') | Where-Object { $_ -notmatch 'MySQL-8.4' } | Set-Content '%SystemRoot%\\System32\\drivers\\etc\\hosts'\" 2>nul\r\n" +
                "echo.\r\n" +
                "echo Служба удалена, автозапуск отключен, резервные копии удалены.\r\n" +
                "echo Запись MySQL-8.4 удалена из hosts.\r\n" +
                $"echo Основная папка \"{BaseFolder}\" осталась (удалите вручную).\r\n" +
                "echo.\r\n" +
                "pause\r\n";

            try
            {
                string batPath = Path.Combine(BaseFolder, "uninstall.bat");
                Encoding oem866 = Encoding.GetEncoding(866);
                File.WriteAllText(batPath, batContent, oem866);
                WriteOk($"Создан: {batPath}");
            }
            catch (Exception ex)
            {
                WriteError($"uninstall.bat: {ex.Message}");
            }
        }

        /// <summary>
        /// Скрытие резервной папки и файлов внутри
        /// </summary>
        static void HideBackupFolder()
        {
            try
            {
                // Скрываем файлы внутри
                foreach (var file in Directory.GetFiles(BackupFolder))
                {
                    File.SetAttributes(file, FileAttributes.Hidden);
                }

                // Скрываем саму папку
                var dirInfo = new DirectoryInfo(BackupFolder);
                dirInfo.Attributes = FileAttributes.Directory | FileAttributes.Hidden | FileAttributes.System;
                WriteOk("Резервная копия скрыта");
            }
            catch (Exception ex)
            {
                WriteError($"Скрытие: {ex.Message}");
            }
        }

        static string RunCmd(string command, bool silent = false)
        {
            try
            {
                var psi = new ProcessStartInfo("cmd.exe", "/c " + command)
                {
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.GetEncoding(866),
                    StandardErrorEncoding = Encoding.GetEncoding(866)
                };
                using (var p = Process.Start(psi))
                {
                    string output = p.StandardOutput.ReadToEnd();
                    string error = p.StandardError.ReadToEnd();
                    p.WaitForExit(15000);
                    return string.IsNullOrEmpty(output) ? error : output;
                }
            }
            catch (Exception ex)
            {
                if (!silent) WriteError($"Команда: {ex.Message}");
                return string.Empty;
            }
        }

        static void WriteStep(string text)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("  ► ");
            Console.ResetColor();
            Console.WriteLine(text);
        }

        static void WriteOk(string text)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("  ✓ ");
            Console.ResetColor();
            Console.WriteLine(text);
        }

        static void WriteError(string text)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("  ✗ ");
            Console.ResetColor();
            Console.WriteLine(text);
        }
    }
}
