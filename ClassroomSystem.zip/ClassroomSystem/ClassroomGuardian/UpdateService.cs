using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Collections.Generic;
using System.Linq;

namespace ClassroomGuardian
{
    /// <summary>
    /// Сервис автообновления через GitHub Releases.
    /// Проверяет latest release, сравнивает версию, скачивает и обновляет.
    /// Также синхронизирует hosts из файла hosts.txt в релизе.
    /// </summary>
    public class UpdateService
    {
        private readonly string _binFolder;
        private readonly string _logFolder;
        private readonly string _backupFolder;
        private readonly string _githubRepo;
        private readonly string _versionFile;
        private readonly Action<string> _log;

        // GitHub API
        private const string GitHubApiBase = "https://api.github.com/repos/{0}/releases/latest";
        private const string UserAgent = "ClassroomGuardian/1.0";

        // Маркер для записей в hosts, управляемых нашей системой
        private const string HostsMarkerStart = "# --- ClassroomSystem BEGIN ---";
        private const string HostsMarkerEnd = "# --- ClassroomSystem END ---";
        private const string HostsFileName = "hosts.txt";

        public UpdateService(string binFolder, string logFolder, string backupFolder, string githubRepo, Action<string> log)
        {
            _binFolder = binFolder;
            _logFolder = logFolder;
            _backupFolder = backupFolder;
            _githubRepo = githubRepo;
            _log = log;
            _versionFile = Path.Combine(binFolder, "version.txt");
        }

        /// <summary>
        /// Проверить и установить обновление. Возвращает true если обновление установлено.
        /// </summary>
        public bool CheckAndUpdate()
        {
            if (string.IsNullOrEmpty(_githubRepo))
                return false;

            try
            {
                // TLS 1.2 обязателен для GitHub
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                string currentVersion = GetCurrentVersion();
                _log($"[Update] Текущая версия: {currentVersion}");

                // Запрашиваем latest release
                string apiUrl = string.Format(GitHubApiBase, _githubRepo);
                string json = DownloadString(apiUrl);

                if (string.IsNullOrEmpty(json))
                {
                    _log("[Update] Не удалось получить данные с GitHub");
                    return false;
                }

                // Парсим version (tag_name) и download URL
                string latestVersion = ExtractJsonValue(json, "tag_name");
                string downloadUrl = FindZipAssetUrl(json);

                if (string.IsNullOrEmpty(latestVersion))
                {
                    _log("[Update] Не найден tag_name в ответе");
                    return false;
                }

                _log($"[Update] Последняя версия на GitHub: {latestVersion}");

                // Сравниваем
                if (string.Equals(currentVersion, latestVersion, StringComparison.OrdinalIgnoreCase))
                {
                    // Версии совпадают — обновление не нужно
                    return false;
                }

                _log($"[Update] Найдено обновление: {currentVersion} → {latestVersion}");

                if (string.IsNullOrEmpty(downloadUrl))
                {
                    _log("[Update] Не найден ZIP-архив в релизе");
                    return false;
                }

                // Скачиваем
                string tempZip = Path.Combine(Path.GetTempPath(), "classroom_update.zip");
                string tempExtract = Path.Combine(Path.GetTempPath(), "classroom_update_" + Guid.NewGuid().ToString("N").Substring(0, 8));

                try
                {
                    _log($"[Update] Скачивание: {downloadUrl}");
                    DownloadFile(downloadUrl, tempZip);

                    // Распаковываем
                    if (Directory.Exists(tempExtract))
                        Directory.Delete(tempExtract, true);
                    ZipFile.ExtractToDirectory(tempZip, tempExtract);

                    // Ищем файлы (могут быть в подпапке)
                    string sourceDir = FindFilesDir(tempExtract);
                    if (sourceDir == null)
                    {
                        _log("[Update] В архиве нет exe/dll файлов");
                        return false;
                    }

                    // Обновляем hosts если есть hosts.txt в архиве
                    string hostsFile = FindHostsFile(tempExtract);
                    if (hostsFile != null)
                    {
                        _log("[Update] Найден hosts.txt в релизе, обновляю системный hosts...");
                        UpdateSystemHosts(hostsFile);
                    }

                    // Останавливаем процессы
                    _log("[Update] Остановка процессов...");
                    KillProcess("ClassroomLogin");
                    KillProcess("SessionWatcher");
                    Thread.Sleep(2000);

                    // Копируем файлы
                    int updated = 0;
                    var patterns = new[] { "*.exe", "*.exe.config", "*.dll", "*.pdb" };
                    foreach (var pattern in patterns)
                    {
                        foreach (var file in Directory.GetFiles(sourceDir, pattern))
                        {
                            string fileName = Path.GetFileName(file);

                            // Не перезаписываем сам Guardian (он запущен)
                            if (fileName.Equals("ClassroomGuardian.exe", StringComparison.OrdinalIgnoreCase) ||
                                fileName.Equals("ClassroomGuardian.exe.config", StringComparison.OrdinalIgnoreCase))
                            {
                                // Guardian обновляется отдельно (через bat-скрипт)
                                string guardianUpdateBat = CreateGuardianUpdateScript(file, fileName);
                                _log($"[Update] Guardian обновится при следующем перезапуске службы: {guardianUpdateBat}");
                                continue;
                            }

                            // Обновляем в bin
                            try
                            {
                                string dest = Path.Combine(_binFolder, fileName);
                                File.Copy(file, dest, true);
                            }
                            catch (Exception ex)
                            {
                                _log($"[Update] Ошибка копирования {fileName} в bin: {ex.Message}");
                            }

                            // Обновляем в скрытой папке
                            try
                            {
                                if (Directory.Exists(_backupFolder))
                                {
                                    string destBackup = Path.Combine(_backupFolder, fileName);
                                    // Снимаем Hidden для перезаписи
                                    if (File.Exists(destBackup))
                                        File.SetAttributes(destBackup, FileAttributes.Normal);
                                    File.Copy(file, destBackup, true);
                                    File.SetAttributes(destBackup, FileAttributes.Hidden);
                                }
                            }
                            catch { }

                            updated++;
                        }
                    }

                    // Сохраняем версию
                    File.WriteAllText(_versionFile, latestVersion);

                    _log($"[Update] Обновлено файлов: {updated}. Версия: {latestVersion}");
                    return updated > 0;
                }
                finally
                {
                    // Чистим временные файлы
                    try { if (File.Exists(tempZip)) File.Delete(tempZip); } catch { }
                    try { if (Directory.Exists(tempExtract)) Directory.Delete(tempExtract, true); } catch { }
                }
            }
            catch (Exception ex)
            {
                _log($"[Update] Ошибка: {ex.Message}");
                return false;
            }
        }

        #region Hosts management

        /// <summary>
        /// Ищет hosts.txt в распакованном архиве (корень или подпапки)
        /// </summary>
        private string FindHostsFile(string root)
        {
            // Проверяем корень
            string path = Path.Combine(root, HostsFileName);
            if (File.Exists(path)) return path;

            // Проверяем подпапки (GitHub zipball может класть в подпапку)
            foreach (var dir in Directory.GetDirectories(root))
            {
                path = Path.Combine(dir, HostsFileName);
                if (File.Exists(path)) return path;

                foreach (var subdir in Directory.GetDirectories(dir))
                {
                    path = Path.Combine(subdir, HostsFileName);
                    if (File.Exists(path)) return path;
                }
            }

            return null;
        }

        /// <summary>
        /// Обновляет системный hosts файл.
        /// Наши записи обрамляются маркерами — при обновлении старый блок заменяется новым.
        /// Чужие записи не трогаем.
        /// 
        /// Формат hosts.txt в релизе (по одной записи на строку):
        ///   172.23.9.151    MySQL-8.4
        ///   10.0.0.5        AppServer
        /// </summary>
        private void UpdateSystemHosts(string hostsFilePath)
        {
            try
            {
                string systemHostsPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.System),
                    @"drivers\etc\hosts");

                // Читаем новые записи из файла в релизе
                var newEntries = File.ReadAllLines(hostsFilePath, Encoding.UTF8)
                    .Select(l => l.Trim())
                    .Where(l => !string.IsNullOrEmpty(l) && !l.StartsWith("#"))
                    .ToList();

                if (newEntries.Count == 0)
                {
                    _log("[Hosts] hosts.txt пустой, пропускаю");
                    return;
                }

                // Читаем текущий системный hosts
                var currentLines = File.Exists(systemHostsPath)
                    ? File.ReadAllLines(systemHostsPath, Encoding.UTF8).ToList()
                    : new List<string>();

                // Удаляем старый блок ClassroomSystem (между маркерами)
                var result = new List<string>();
                bool insideBlock = false;
                foreach (var line in currentLines)
                {
                    if (line.TrimStart().StartsWith(HostsMarkerStart))
                    {
                        insideBlock = true;
                        continue;
                    }
                    if (line.TrimStart().StartsWith(HostsMarkerEnd))
                    {
                        insideBlock = false;
                        continue;
                    }
                    if (!insideBlock)
                        result.Add(line);
                }

                // Убираем пустые строки в конце
                while (result.Count > 0 && string.IsNullOrWhiteSpace(result[result.Count - 1]))
                    result.RemoveAt(result.Count - 1);

                // Добавляем новый блок
                result.Add("");
                result.Add(HostsMarkerStart);
                foreach (var entry in newEntries)
                {
                    result.Add(entry);
                    _log($"[Hosts] + {entry}");
                }
                result.Add(HostsMarkerEnd);

                // Записываем
                File.WriteAllLines(systemHostsPath, result, Encoding.UTF8);

                // Сбрасываем DNS-кэш
                try
                {
                    var psi = new ProcessStartInfo("ipconfig", "/flushdns")
                    {
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardOutput = true
                    };
                    using (var p = Process.Start(psi))
                    {
                        p.WaitForExit(5000);
                    }
                }
                catch { }

                _log($"[Hosts] Обновлено: {newEntries.Count} записей, DNS-кэш сброшен");

                // Сохраняем копию hosts.txt в bin для справки
                try
                {
                    File.Copy(hostsFilePath, Path.Combine(_binFolder, HostsFileName), true);
                }
                catch { }
            }
            catch (Exception ex)
            {
                _log($"[Hosts] Ошибка обновления hosts: {ex.Message}");
            }
        }

        #endregion

        private string GetCurrentVersion()
        {
            try
            {
                if (File.Exists(_versionFile))
                    return File.ReadAllText(_versionFile).Trim();
            }
            catch { }
            return "none";
        }

        /// <summary>
        /// Создаёт bat-скрипт для обновления Guardian при перезапуске
        /// </summary>
        private string CreateGuardianUpdateScript(string newFile, string fileName)
        {
            string pendingDir = Path.Combine(_binFolder, "pending_update");
            Directory.CreateDirectory(pendingDir);
            File.Copy(newFile, Path.Combine(pendingDir, fileName), true);

            // bat-скрипт: остановит службу, заменит файл, запустит
            string batPath = Path.Combine(_binFolder, "apply_guardian_update.bat");
            string batContent =
                "@echo off\r\n" +
                "timeout /t 3 /nobreak >nul\r\n" +
                "net stop ClassroomGuardian\r\n" +
                "timeout /t 2 /nobreak >nul\r\n" +
                $"copy /y \"{Path.Combine(pendingDir, "ClassroomGuardian.exe")}\" \"{Path.Combine(_binFolder, "ClassroomGuardian.exe")}\"\r\n" +
                $"if exist \"{Path.Combine(pendingDir, "ClassroomGuardian.exe.config")}\" copy /y \"{Path.Combine(pendingDir, "ClassroomGuardian.exe.config")}\" \"{Path.Combine(_binFolder, "ClassroomGuardian.exe.config")}\"\r\n" +
                "net start ClassroomGuardian\r\n" +
                $"rmdir /s /q \"{pendingDir}\"\r\n" +
                $"del \"%~f0\"\r\n";

            File.WriteAllText(batPath, batContent, Encoding.GetEncoding(866));
            return batPath;
        }

        #region HTTP helpers (без внешних зависимостей)

        private string DownloadString(string url)
        {
            try
            {
                using (var wc = new WebClient())
                {
                    wc.Headers.Add("User-Agent", UserAgent);
                    wc.Encoding = Encoding.UTF8;
                    return wc.DownloadString(url);
                }
            }
            catch (WebException ex)
            {
                _log($"[Update] HTTP ошибка: {ex.Message}");
                return null;
            }
        }

        private void DownloadFile(string url, string destPath)
        {
            using (var wc = new WebClient())
            {
                wc.Headers.Add("User-Agent", UserAgent);
                wc.DownloadFile(url, destPath);
            }
        }

        #endregion

        #region JSON parsing (минимальный, без зависимостей)

        /// <summary>
        /// Извлекает значение строкового поля из JSON
        /// </summary>
        private string ExtractJsonValue(string json, string key)
        {
            // Ищем "key": "value"
            string pattern = $"\"{key}\"\\s*:\\s*\"([^\"]+)\"";
            var match = Regex.Match(json, pattern);
            return match.Success ? match.Groups[1].Value : null;
        }

        /// <summary>
        /// Находит URL первого .zip ассета в релизе
        /// </summary>
        private string FindZipAssetUrl(string json)
        {
            // Ищем browser_download_url с .zip
            var matches = Regex.Matches(json, "\"browser_download_url\"\\s*:\\s*\"([^\"]+\\.zip)\"");
            if (matches.Count > 0)
                return matches[0].Groups[1].Value;

            // Если нет zip ассета, берём zipball_url (исходный код)
            return ExtractJsonValue(json, "zipball_url");
        }

        #endregion

        /// <summary>
        /// Ищет папку с exe/dll (может быть вложенная)
        /// </summary>
        private string FindFilesDir(string root)
        {
            // Проверяем корень
            if (Directory.GetFiles(root, "*.exe").Length > 0)
                return root;

            // Проверяем подпапки (одна вложенность)
            foreach (var dir in Directory.GetDirectories(root))
            {
                if (Directory.GetFiles(dir, "*.exe").Length > 0)
                    return dir;

                // Ещё одна вложенность (GitHub zipball добавляет папку с хешем)
                foreach (var subdir in Directory.GetDirectories(dir))
                {
                    if (Directory.GetFiles(subdir, "*.exe").Length > 0)
                        return subdir;
                }
            }

            return null;
        }

        private void KillProcess(string name)
        {
            try
            {
                foreach (var p in Process.GetProcessesByName(name))
                {
                    try { p.Kill(); } catch { }
                }
            }
            catch { }
        }
    }
}
