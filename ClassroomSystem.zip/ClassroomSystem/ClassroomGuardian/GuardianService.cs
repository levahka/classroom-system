using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace ClassroomGuardian
{
    /// <summary>
    /// Служба-страж компьютерного класса.
    /// Восстанавливает файлы из резервной копии,
    /// следит за запуском ClassroomLogin и SessionWatcher.
    /// Запускает процессы в интерактивной сессии пользователя через Win32 API.
    /// </summary>
    public class GuardianService : ServiceBase
    {
        #region Win32 API

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern uint WTSGetActiveConsoleSessionId();

        [DllImport("wtsapi32.dll", SetLastError = true)]
        static extern bool WTSQueryUserToken(uint sessionId, out IntPtr token);

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static extern bool DuplicateTokenEx(
            IntPtr hExistingToken, uint dwDesiredAccess, IntPtr lpTokenAttributes,
            int impersonationLevel, int tokenType, out IntPtr phNewToken);

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool CreateProcessAsUser(
            IntPtr hToken, string lpApplicationName, string lpCommandLine,
            IntPtr lpProcessAttributes, IntPtr lpThreadAttributes,
            bool bInheritHandles, uint dwCreationFlags, IntPtr lpEnvironment,
            string lpCurrentDirectory, ref STARTUPINFO lpStartupInfo,
            out PROCESS_INFORMATION lpProcessInformation);

        [DllImport("advapi32.dll", SetLastError = true)]
        static extern bool GetTokenInformation(
            IntPtr tokenHandle, int tokenInformationClass,
            IntPtr tokenInformation, int tokenInformationLength, out int returnLength);

        [DllImport("advapi32.dll", SetLastError = true)]
        static extern bool OpenProcessToken(IntPtr processHandle, uint desiredAccess, out IntPtr tokenHandle);

        [DllImport("advapi32.dll", SetLastError = true)]
        static extern bool SetTokenInformation(
            IntPtr tokenHandle, int tokenInformationClass,
            ref uint tokenInformation, int tokenInformationLength);

        [DllImport("userenv.dll", SetLastError = true)]
        static extern bool CreateEnvironmentBlock(out IntPtr lpEnvironment, IntPtr hToken, bool bInherit);

        [DllImport("userenv.dll", SetLastError = true)]
        static extern bool DestroyEnvironmentBlock(IntPtr lpEnvironment);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr hObject);

        [DllImport("kernel32.dll")]
        static extern IntPtr GetCurrentProcess();

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct STARTUPINFO
        {
            public int cb;
            public string lpReserved;
            public string lpDesktop;
            public string lpTitle;
            public int dwX, dwY, dwXSize, dwYSize;
            public int dwXCountChars, dwYCountChars;
            public int dwFillAttribute;
            public int dwFlags;
            public short wShowWindow;
            public short cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput, hStdOutput, hStdError;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public int dwProcessId;
            public int dwThreadId;
        }

        const uint GENERIC_ALL_ACCESS = 0x10000000;
        const uint MAXIMUM_ALLOWED = 0x02000000;
        const uint TOKEN_ALL_ACCESS = 0x000F01FF;
        const uint TOKEN_QUERY = 0x0008;
        const uint TOKEN_DUPLICATE = 0x0002;
        const uint TOKEN_ASSIGN_PRIMARY = 0x0001;
        const int SecurityImpersonation = 2;
        const int TokenPrimary = 1;
        const uint CREATE_UNICODE_ENVIRONMENT = 0x00000400;
        const int STARTF_USESHOWWINDOW = 0x00000001;
        const short SW_SHOW = 5;

        // TokenInformationClass
        const int TokenSessionId = 12;
        const int TokenLinkedToken = 19;
        const int TokenElevationType = 18;

        // TOKEN_ELEVATION_TYPE
        const int TokenElevationTypeDefault = 1;
        const int TokenElevationTypeFull = 2;
        const int TokenElevationTypeLimited = 3;

        #endregion

        private Timer _timer;
        private Timer _updateTimer;
        private readonly string _baseFolder;
        private readonly string _binFolder;
        private readonly string _logFolder;
        private readonly string _backupFolder;
        private readonly int _checkIntervalSeconds;
        private readonly string _logFile;
        private readonly string _githubRepo;
        private readonly int _updateCheckMinutes;

        private readonly Dictionary<string, DateTime> _lastLaunchAttempt =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        private const int LaunchCooldownSeconds = 60;

        // Защита от двойного логина: помним, когда сессия последний раз была активна
        private DateTime _sessionFileLastSeen = DateTime.MinValue;
        private const int SessionGraceSeconds = 120; // не запускать Login в течение 2 мин после исчезновения сессии

        public GuardianService()
        {
            ServiceName = "ClassroomGuardian";
            CanStop = true;
            CanShutdown = true;

            _baseFolder = ConfigurationManager.AppSettings["BaseFolder"] ?? @"C:\Program Files\ClassroomSystem";
            string binSub = ConfigurationManager.AppSettings["BinFolder"] ?? "bin";
            string logSub = ConfigurationManager.AppSettings["LogFolder"] ?? "logs";
            _binFolder = Path.Combine(_baseFolder, binSub);
            _logFolder = Path.Combine(_baseFolder, logSub);
            _backupFolder = ConfigurationManager.AppSettings["BackupFolder"] ?? @"C:\ProgramData\Microsoft\Diagnostics";
            _checkIntervalSeconds = int.TryParse(ConfigurationManager.AppSettings["CheckIntervalSeconds"], out int interval) ? interval : 15;
            _logFile = ConfigurationManager.AppSettings["LogFile"] ?? "guardian_debug.log";
            _githubRepo = ConfigurationManager.AppSettings["GitHubRepo"] ?? "";
            _updateCheckMinutes = int.TryParse(ConfigurationManager.AppSettings["UpdateCheckMinutes"], out int um) ? um : 10;
        }

        protected override void OnStart(string[] args)
        {
            Log("========== ClassroomGuardian запущен ==========");
            Log($"Папка программ: {_binFolder}");
            Log($"Папка логов: {_logFolder}");
            Log($"Интервал проверки: {_checkIntervalSeconds} сек");

            VerifyDirectories();
            _timer = new Timer(OnTimerTick, null, TimeSpan.FromSeconds(5), TimeSpan.FromSeconds(_checkIntervalSeconds));

            // Таймер обновлений (первая проверка через 30 сек после старта)
            if (!string.IsNullOrEmpty(_githubRepo))
            {
                Log($"Автообновление: {_githubRepo}, интервал {_updateCheckMinutes} мин");
                _updateTimer = new Timer(OnUpdateCheck, null,
                    TimeSpan.FromSeconds(30),
                    TimeSpan.FromMinutes(_updateCheckMinutes));
            }
        }

        protected override void OnStop()
        {
            Log("========== ClassroomGuardian остановлен ==========");
            DisposeTimer();
        }

        protected override void OnShutdown()
        {
            Log("========== Завершение системы ==========");
            DisposeTimer();
        }

        private void DisposeTimer()
        {
            if (_updateTimer != null)
            {
                _updateTimer.Change(Timeout.Infinite, Timeout.Infinite);
                _updateTimer.Dispose();
                _updateTimer = null;
            }
            if (_timer != null)
            {
                _timer.Change(Timeout.Infinite, Timeout.Infinite);
                _timer.Dispose();
                _timer = null;
            }
        }

        /// <summary>
        /// Проверка обновлений на GitHub
        /// </summary>
        private void OnUpdateCheck(object state)
        {
            try
            {
                var updater = new UpdateService(_binFolder, _logFolder, _backupFolder, _githubRepo, Log);
                if (updater.CheckAndUpdate())
                {
                    Log("[Update] Обновление установлено, процессы будут перезапущены автоматически");
                    // Процессы были убиты в UpdateService, Guardian перезапустит их в следующем тике
                }
            }
            catch (Exception ex)
            {
                Log($"[Update] Ошибка проверки: {ex.Message}");
            }
        }

        private void VerifyDirectories()
        {
            try
            {
                if (!Directory.Exists(_binFolder)) Directory.CreateDirectory(_binFolder);
                if (!Directory.Exists(_logFolder)) Directory.CreateDirectory(_logFolder);
            }
            catch (Exception ex) { Log($"Ошибка создания директорий: {ex.Message}"); }

            try { if (!Directory.Exists(_backupFolder)) Directory.CreateDirectory(_backupFolder); }
            catch { }
        }

        private void OnTimerTick(object state)
        {
            try
            {
                CheckFileIntegrity();
                CheckProcesses();
            }
            catch (Exception ex) { Log($"Ошибка в цикле: {ex.Message}"); }
        }

        private void CheckFileIntegrity()
        {
            if (!Directory.Exists(_backupFolder)) return;

            try
            {
                var patterns = new[] { "*.exe", "*.config", "*.dll" };
                var backupFiles = new List<string>();
                foreach (var p in patterns)
                    backupFiles.AddRange(Directory.GetFiles(_backupFolder, p, SearchOption.TopDirectoryOnly));

                foreach (var bf in backupFiles)
                {
                    string fn = Path.GetFileName(bf);
                    string mainPath = Path.Combine(_binFolder, fn);
                    if (!File.Exists(mainPath))
                    {
                        try { File.Copy(bf, mainPath, true); Log($"Восстановлен: {fn}"); }
                        catch (Exception ex) { Log($"Ошибка восстановления {fn}: {ex.Message}"); }
                    }
                }
            }
            catch (Exception ex) { Log($"Ошибка проверки целостности: {ex.Message}"); }
        }

        private void CheckProcesses()
        {
            string sessionFile = Path.Combine(_logFolder, "current_session.txt");
            bool sessionActive = File.Exists(sessionFile);

            if (sessionActive)
            {
                // Запоминаем, что сессия жива
                _sessionFileLastSeen = DateTime.Now;

                if (!IsProcessRunning("SessionWatcher"))
                {
                    string watcherExe = Path.Combine(_binFolder, "SessionWatcher.exe");
                    if (File.Exists(watcherExe))
                        LaunchWithCooldown("SessionWatcher", watcherExe);
                }
            }
            else
            {
                // Сессия НЕ активна — но не спешим запускать Login

                // 1) Если ClassroomLogin уже запущен — ничего не делаем
                if (IsProcessRunning("ClassroomLogin"))
                    return;

                // 2) Если сессия была активна недавно — это переходный момент, ждём
                double secsSinceSession = (DateTime.Now - _sessionFileLastSeen).TotalSeconds;
                if (_sessionFileLastSeen != DateTime.MinValue && secsSinceSession < SessionGraceSeconds)
                {
                    Log($"Сессия исчезла {secsSinceSession:F0} сек назад, grace period ({SessionGraceSeconds} сек) — не запускаем Login");
                    return;
                }

                // 3) Если SessionWatcher ещё работает — сессия завершается, ждём
                if (IsProcessRunning("SessionWatcher"))
                    return;

                // 4) Всё чисто — запускаем Login
                string loginExe = Path.Combine(_binFolder, "ClassroomLogin.exe");
                if (File.Exists(loginExe))
                    LaunchWithCooldown("ClassroomLogin", loginExe);
            }
        }

        private bool IsProcessRunning(string name)
        {
            try { return Process.GetProcessesByName(name).Length > 0; }
            catch { return false; }
        }

        private void LaunchWithCooldown(string processName, string exePath)
        {
            lock (_lastLaunchAttempt)
            {
                if (_lastLaunchAttempt.TryGetValue(processName, out DateTime last))
                    if ((DateTime.Now - last).TotalSeconds < LaunchCooldownSeconds) return;
                _lastLaunchAttempt[processName] = DateTime.Now;
            }

            Log($"Запуск {processName}...");

            // Способ 1: SYSTEM-токен в пользовательской сессии (с elevation)
            if (TryLaunchAsSystem(exePath))
                return;

            // Способ 2: User token с linked elevated token
            if (TryLaunchViaUserToken(exePath))
                return;

            // Способ 3: schtasks
            if (TryLaunchViaSchtasks(exePath))
                return;

            Log($"Все способы запуска исчерпаны для {Path.GetFileName(exePath)}");
        }

        /// <summary>
        /// ОСНОВНОЙ СПОСОБ: берём токен SYSTEM (нашего процесса),
        /// дублируем его, переключаем на пользовательскую сессию.
        /// Процесс запустится с правами SYSTEM на десктопе пользователя.
        /// Это обходит UAC полностью.
        /// </summary>
        private bool TryLaunchAsSystem(string exePath)
        {
            IntPtr systemToken = IntPtr.Zero;
            IntPtr duplicateToken = IntPtr.Zero;
            IntPtr environment = IntPtr.Zero;

            try
            {
                uint sessionId = WTSGetActiveConsoleSessionId();
                if (sessionId == 0xFFFFFFFF)
                {
                    Log("Нет активной сессии");
                    return false;
                }

                // Берём токен нашего процесса (SYSTEM)
                if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, out systemToken))
                {
                    Log($"OpenProcessToken ошибка: {Marshal.GetLastWin32Error()}");
                    return false;
                }

                // Дублируем
                if (!DuplicateTokenEx(systemToken, MAXIMUM_ALLOWED, IntPtr.Zero,
                    SecurityImpersonation, TokenPrimary, out duplicateToken))
                {
                    Log($"DuplicateTokenEx ошибка: {Marshal.GetLastWin32Error()}");
                    return false;
                }

                // Переключаем токен на пользовательскую сессию
                uint sid = sessionId;
                if (!SetTokenInformation(duplicateToken, TokenSessionId, ref sid, sizeof(uint)))
                {
                    Log($"SetTokenInformation(SessionId) ошибка: {Marshal.GetLastWin32Error()}");
                    return false;
                }

                // Создаём окружение для этой сессии
                CreateEnvironmentBlock(out environment, duplicateToken, false);

                var si = new STARTUPINFO();
                si.cb = Marshal.SizeOf(si);
                si.lpDesktop = @"winsta0\default";
                si.dwFlags = STARTF_USESHOWWINDOW;
                si.wShowWindow = SW_SHOW;

                bool ok = CreateProcessAsUser(
                    duplicateToken, exePath, null,
                    IntPtr.Zero, IntPtr.Zero, false,
                    CREATE_UNICODE_ENVIRONMENT,
                    environment,
                    Path.GetDirectoryName(exePath),
                    ref si, out PROCESS_INFORMATION pi);

                if (ok)
                {
                    Log($"Запущен (SYSTEM→Session {sessionId}): {Path.GetFileName(exePath)} PID={pi.dwProcessId}");
                    CloseHandle(pi.hProcess);
                    CloseHandle(pi.hThread);
                    return true;
                }

                int err = Marshal.GetLastWin32Error();
                Log($"CreateProcessAsUser(SYSTEM) ошибка {err}: {new Win32Exception(err).Message}");
                return false;
            }
            catch (Exception ex)
            {
                Log($"SYSTEM-запуск исключение: {ex.Message}");
                return false;
            }
            finally
            {
                if (environment != IntPtr.Zero) DestroyEnvironmentBlock(environment);
                if (duplicateToken != IntPtr.Zero) CloseHandle(duplicateToken);
                if (systemToken != IntPtr.Zero) CloseHandle(systemToken);
            }
        }

        /// <summary>
        /// ЗАПАСНОЙ: берём токен пользователя, если UAC включён - получаем linked elevated token.
        /// </summary>
        private bool TryLaunchViaUserToken(string exePath)
        {
            IntPtr userToken = IntPtr.Zero;
            IntPtr elevatedToken = IntPtr.Zero;
            IntPtr environment = IntPtr.Zero;

            try
            {
                uint sessionId = WTSGetActiveConsoleSessionId();
                if (sessionId == 0xFFFFFFFF) return false;

                if (!WTSQueryUserToken(sessionId, out userToken))
                {
                    Log($"WTSQueryUserToken ошибка: {Marshal.GetLastWin32Error()}");
                    return false;
                }

                // Проверяем тип elevation
                IntPtr elevationTypePtr = Marshal.AllocHGlobal(4);
                try
                {
                    GetTokenInformation(userToken, TokenElevationType, elevationTypePtr, 4, out _);
                    int elevationType = Marshal.ReadInt32(elevationTypePtr);

                    if (elevationType == TokenElevationTypeLimited)
                    {
                        // UAC включён, есть linked elevated token
                        IntPtr linkedTokenPtr = Marshal.AllocHGlobal(IntPtr.Size);
                        try
                        {
                            if (GetTokenInformation(userToken, TokenLinkedToken, linkedTokenPtr, IntPtr.Size, out _))
                            {
                                IntPtr linkedToken = Marshal.ReadIntPtr(linkedTokenPtr);
                                // Дублируем linked token как primary
                                if (DuplicateTokenEx(linkedToken, MAXIMUM_ALLOWED, IntPtr.Zero,
                                    SecurityImpersonation, TokenPrimary, out elevatedToken))
                                {
                                    Log("Получен elevated token через linked token");
                                }
                                CloseHandle(linkedToken);
                            }
                        }
                        finally { Marshal.FreeHGlobal(linkedTokenPtr); }
                    }
                    else if (elevationType == TokenElevationTypeFull)
                    {
                        // Уже elevated
                        DuplicateTokenEx(userToken, MAXIMUM_ALLOWED, IntPtr.Zero,
                            SecurityImpersonation, TokenPrimary, out elevatedToken);
                        Log("Токен уже elevated");
                    }
                    else
                    {
                        // UAC выключен или default — просто дублируем
                        DuplicateTokenEx(userToken, MAXIMUM_ALLOWED, IntPtr.Zero,
                            SecurityImpersonation, TokenPrimary, out elevatedToken);
                    }
                }
                finally { Marshal.FreeHGlobal(elevationTypePtr); }

                if (elevatedToken == IntPtr.Zero)
                {
                    Log("Не удалось получить elevated token");
                    return false;
                }

                CreateEnvironmentBlock(out environment, elevatedToken, false);

                var si = new STARTUPINFO();
                si.cb = Marshal.SizeOf(si);
                si.lpDesktop = @"winsta0\default";
                si.dwFlags = STARTF_USESHOWWINDOW;
                si.wShowWindow = SW_SHOW;

                bool ok = CreateProcessAsUser(
                    elevatedToken, exePath, null,
                    IntPtr.Zero, IntPtr.Zero, false,
                    CREATE_UNICODE_ENVIRONMENT,
                    environment,
                    Path.GetDirectoryName(exePath),
                    ref si, out PROCESS_INFORMATION pi);

                if (ok)
                {
                    Log($"Запущен (elevated user): {Path.GetFileName(exePath)} PID={pi.dwProcessId}");
                    CloseHandle(pi.hProcess);
                    CloseHandle(pi.hThread);
                    return true;
                }

                int err = Marshal.GetLastWin32Error();
                Log($"CreateProcessAsUser(elevated) ошибка {err}: {new Win32Exception(err).Message}");
                return false;
            }
            catch (Exception ex)
            {
                Log($"Elevated-запуск исключение: {ex.Message}");
                return false;
            }
            finally
            {
                if (environment != IntPtr.Zero) DestroyEnvironmentBlock(environment);
                if (elevatedToken != IntPtr.Zero) CloseHandle(elevatedToken);
                if (userToken != IntPtr.Zero) CloseHandle(userToken);
            }
        }

        /// <summary>
        /// Последний вариант: schtasks с /rl highest
        /// </summary>
        private bool TryLaunchViaSchtasks(string exePath)
        {
            try
            {
                string taskName = "CG_" + Guid.NewGuid().ToString("N").Substring(0, 8);

                // Создаём задачу от SYSTEM с highest privileges
                RunCmd($"schtasks /create /tn \"{taskName}\" /tr \"\\\"{exePath}\\\"\" /sc once /st 00:00 /f /rl highest /ru SYSTEM");
                string result = RunCmd($"schtasks /run /tn \"{taskName}\"");
                Thread.Sleep(3000);
                RunCmd($"schtasks /delete /tn \"{taskName}\" /f");

                if (result.Contains("SUCCESS") || result.Contains("успешно"))
                {
                    Log($"Запущен (schtasks): {Path.GetFileName(exePath)}");
                    return true;
                }

                Log($"schtasks результат: {result.Trim()}");
                return false;
            }
            catch (Exception ex)
            {
                Log($"schtasks ошибка: {ex.Message}");
                return false;
            }
        }

        private string RunCmd(string args)
        {
            try
            {
                var psi = new ProcessStartInfo("cmd.exe", "/c " + args)
                {
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };
                using (var p = Process.Start(psi))
                {
                    string output = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(10000);
                    return output;
                }
            }
            catch { return string.Empty; }
        }

        private void Log(string message)
        {
            try
            {
                string logPath = Path.Combine(_logFolder, _logFile);
                string line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {message}";
                File.AppendAllText(logPath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }
    }
}
