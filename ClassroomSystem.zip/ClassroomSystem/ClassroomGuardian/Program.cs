using System.ServiceProcess;

namespace ClassroomGuardian
{
    /// <summary>
    /// Точка входа службы ClassroomGuardian
    /// </summary>
    static class Program
    {
        static void Main()
        {
            ServiceBase.Run(new ServiceBase[] { new GuardianService() });
        }
    }
}
