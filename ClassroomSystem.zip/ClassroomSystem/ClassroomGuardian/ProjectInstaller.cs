using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace ClassroomGuardian
{
    /// <summary>
    /// Инсталлятор службы ClassroomGuardian.
    /// Используется при установке через InstallUtil.exe
    /// </summary>
    [RunInstaller(true)]
    public class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {
            // Запуск от имени LocalSystem — максимальные привилегии
            var processInstaller = new ServiceProcessInstaller
            {
                Account = ServiceAccount.LocalSystem
            };

            var serviceInstaller = new ServiceInstaller
            {
                ServiceName = "ClassroomGuardian",
                DisplayName = "Classroom Management Service",
                Description = "Служба управления компьютерным классом",
                StartType = ServiceStartMode.Automatic
            };

            Installers.Add(processInstaller);
            Installers.Add(serviceInstaller);
        }
    }
}
