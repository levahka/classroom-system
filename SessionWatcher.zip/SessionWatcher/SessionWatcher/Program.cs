﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace SessionWatcher
{
    static class Program
    {
        private static Mutex _mutex;
        private const string MutexName = "SessionWatcher_SingleInstance_v2";

        [STAThread]
        static void Main()
        {
            bool createdNew;
            _mutex = new Mutex(true, MutexName, out createdNew);

            if (!createdNew)
            {
                // Уже запущен
                return;
            }

            try
            {
                Logger.Log("══════════════════════════════════════");
                Logger.Log("=== SessionWatcher v2 запущен ===");
                Logger.Log($"PID: {Process.GetCurrentProcess().Id}");
                Logger.Log($"Компьютер: {Environment.MachineName}");
                Logger.Log($"Пользователь: {Environment.UserName}");
                Logger.Log($"Время: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                Logger.Log("══════════════════════════════════════");

                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += OnThreadException;
                AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                Application.Run(new HiddenForm());
            }
            catch (Exception ex)
            {
                Logger.LogError("Критическая ошибка Main", ex);
            }
            finally
            {
                _mutex?.ReleaseMutex();
                _mutex?.Dispose();
                Logger.Log("=== SessionWatcher v2 завершён ===");
            }
        }

        private static void OnThreadException(object sender, ThreadExceptionEventArgs e)
        {
            Logger.LogError("ThreadException", e.Exception);
        }

        private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex)
                Logger.LogError("UnhandledException", ex);
        }
    }
}
