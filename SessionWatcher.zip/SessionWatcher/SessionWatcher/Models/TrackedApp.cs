﻿using System;

namespace SessionWatcher.Models
{
    /// <summary>
    /// Отслеживаемое приложение из БД
    /// </summary>
    public class TrackedApp
    {
        public int Id { get; set; }

        /// <summary>
        /// Имя процесса (с .exe). Может быть null для WINDOW_TITLE
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// Человеко-читаемое название
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Категория: GAME, LAUNCHER, BROWSER_GAME, SOCIAL_MEDIA, OTHER
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Тип обнаружения: PROCESS, WINDOW_TITLE, BOTH
        /// </summary>
        public string DetectionType { get; set; }

        /// <summary>
        /// Подстрока для поиска в заголовке окна
        /// </summary>
        public string TitlePattern { get; set; }

        public bool IsActive { get; set; } = true;
        public DateTime UpdatedAt { get; set; }

        /// <summary>
        /// Имя процесса без расширения (для сравнения с Process.ProcessName)
        /// </summary>
        public string ProcessNameWithoutExtension
        {
            get
            {
                if (string.IsNullOrEmpty(ProcessName))
                    return null;
                return System.IO.Path.GetFileNameWithoutExtension(ProcessName);
            }
        }

        public override string ToString()
        {
            return $"{DisplayName} [{Category}] ({DetectionType}: {ProcessName ?? TitlePattern})";
        }
    }
}
