﻿using System;
using System.Linq;

namespace SessionWatcher.Models
{
    /// <summary>
    /// Модель данных сессии
    /// </summary>
    public class SessionData
    {
        public string SessionId { get; set; }
        public string ComputerName { get; set; }
        public string GroupName { get; set; }
        public string Surname { get; set; }
        public DateTime LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }
        public int DurationMinutes { get; set; }
        public string Status { get; set; } = "АКТИВЕН";
        public string ComputerProblem { get; set; } = "OK";
        public DateTime? LastHeartbeat { get; set; }
        public string IpAddress { get; set; }

        /// <summary>
        /// Создаёт SessionData из строки файла сессии
        /// </summary>
        public static SessionData FromSessionFile(string sessionFileContent, string csvLine = null)
        {
            if (string.IsNullOrWhiteSpace(sessionFileContent))
                return null;

            var parts = sessionFileContent.Split('|');
            if (parts.Length < 2)
                return null;

            var data = new SessionData
            {
                SessionId = parts[0].Trim(),
                ComputerName = Environment.MachineName,
                LastHeartbeat = DateTime.Now
            };

            // Парсим время входа
            DateTime loginTime;
            if (DateTime.TryParse(parts[1].Trim(), out loginTime))
                data.LoginTime = loginTime;
            else
                data.LoginTime = DateTime.Now;

            // Данные из CSV
            if (!string.IsNullOrEmpty(csvLine))
            {
                var columns = csvLine.Split(';');
                // CSV: ID;Дата;Группа;Фамилия;Компьютер;Вход;Выход;Длит;Статус;Проблемы
                //       0   1     2       3        4      5     6    7     8      9
                if (columns.Length >= 10)
                {
                    data.GroupName = columns[2];
                    data.Surname = columns[3];
                    data.Status = columns[8];
                    data.ComputerProblem = columns[9];
                }
            }

            // IP-адрес
            try
            {
                var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                foreach (var ip in host.AddressList)
                {
                    if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        data.IpAddress = ip.ToString();
                        break;
                    }
                }
            }
            catch { }

            return data;
        }

        /// <summary>
        /// Пересчитывает длительность
        /// </summary>
        public void UpdateDuration()
        {
            var endTime = LogoutTime ?? DateTime.Now;
            DurationMinutes = (int)(endTime - LoginTime).TotalMinutes;
        }
    }

    /// <summary>
    /// Элемент очереди синхронизации (универсальный)
    /// </summary>
    public class SyncQueueItem
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public string SessionId { get; set; }
        public string ActionType { get; set; }
        // INSERT, UPDATE, CLOSE — для сессий
        // ACTIVITY_START, ACTIVITY_END, ACTIVITY_HEARTBEAT — для активностей

        public SessionData Data { get; set; }
        public ActivityEvent ActivityData { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public int RetryCount { get; set; } = 0;
    }
}
