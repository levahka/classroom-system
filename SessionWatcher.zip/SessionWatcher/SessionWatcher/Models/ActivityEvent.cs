﻿using System;

namespace SessionWatcher.Models
{
    /// <summary>
    /// Событие обнаруженной активности
    /// </summary>
    public class ActivityEvent
    {
        /// <summary>
        /// Уникальный идентификатор (GUID), генерируется клиентом
        /// </summary>
        public string ActivityId { get; set; } = Guid.NewGuid().ToString("N").Substring(0, 20);

        public string SessionId { get; set; }
        public string ComputerName { get; set; }

        /// <summary>
        /// ID из таблицы tracked_apps (может быть null)
        /// </summary>
        public int? TrackedAppId { get; set; }

        /// <summary>
        /// Название приложения (display name)
        /// </summary>
        public string AppName { get; set; }

        /// <summary>
        /// Имя процесса (например "chrome", "minecraft") — для taskkill
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// Категория: GAME, LAUNCHER, BROWSER_GAME и т.д.
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Заголовок окна в момент обнаружения
        /// </summary>
        public string WindowTitle { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public int DurationSeconds { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime LastSeen { get; set; } = DateTime.Now;

        /// <summary>
        /// Пересчитать длительность
        /// </summary>
        public void UpdateDuration()
        {
            var end = EndTime ?? DateTime.Now;
            DurationSeconds = (int)(end - StartTime).TotalSeconds;
        }

        /// <summary>
        /// Отметить завершение
        /// </summary>
        public void MarkEnded()
        {
            EndTime = DateTime.Now;
            IsActive = false;
            UpdateDuration();
        }

        public override string ToString()
        {
            string dur = IsActive ? "активно" : $"{DurationSeconds}с";
            return $"{AppName} [{Category}] ({dur})";
        }
    }
}
