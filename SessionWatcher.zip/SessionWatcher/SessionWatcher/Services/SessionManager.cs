﻿using System;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using SessionWatcher.Models;

namespace SessionWatcher.Services
{
    /// <summary>
    /// Главный менеджер: сессия + мониторинг активности + удалённые команды
    /// </summary>
    public class SessionManager : IDisposable
    {
        private readonly LocalStorageService _localStorage;
        private readonly DatabaseService _database;
        private readonly ActivityMonitorService _activityMonitor;
        private readonly RemoteCommandService _remoteCommands;

        private Timer _updateTimer;
        private Timer _syncTimer;

        private SessionData _currentSession;
        private bool _isRunning;
        private bool _isDisposed;
        private readonly object _lockObject = new object();

        private readonly int _updateIntervalMs;
        private readonly int _syncIntervalMs;
        private readonly int _maxRetryAttempts;
        private readonly bool _enableActivityMonitoring;

        public event Action<string> StatusChanged;

        public SessionManager()
        {
            _localStorage = new LocalStorageService();
            _database = new DatabaseService();
            _activityMonitor = new ActivityMonitorService(_database, _localStorage);
            _remoteCommands = new RemoteCommandService(_database, Environment.MachineName);

            _updateIntervalMs = int.Parse(
                ConfigurationManager.AppSettings["UpdateIntervalSeconds"] ?? "30") * 1000;
            _syncIntervalMs = int.Parse(
                ConfigurationManager.AppSettings["SyncRetryIntervalSeconds"] ?? "120") * 1000;
            _maxRetryAttempts = int.Parse(
                ConfigurationManager.AppSettings["MaxRetryAttempts"] ?? "5");

            string enableStr = ConfigurationManager.AppSettings["EnableActivityMonitoring"] ?? "true";
            _enableActivityMonitoring = enableStr.Equals("true", StringComparison.OrdinalIgnoreCase);

            _database.ConnectionStateChanged += OnConnectionStateChanged;

            _activityMonitor.OnActivityStarted += evt =>
                StatusChanged?.Invoke($"⚠ {evt.AppName} [{evt.Category}]");
            _activityMonitor.OnActivityEnded += evt =>
                StatusChanged?.Invoke($"✓ {evt.AppName} завершено");

            _remoteCommands.OnLog += msg => Logger.Log(msg);
        }

        private void OnConnectionStateChanged(bool isConnected)
        {
            string status = isConnected ? "БД подключена" : "БД недоступна (офлайн)";
            Logger.Log(status);
            StatusChanged?.Invoke(status);
        }

        /// <summary>
        /// Запуск
        /// </summary>
        public async Task StartAsync()
        {
            if (_isRunning) return;

            Logger.Log("=== SessionManager: запуск ===");

            _currentSession = _localStorage.ReadCurrentSession();

            if (_currentSession == null)
            {
                Logger.Log("Нет активной сессии — мониторинг не запущен");
                return;
            }

            Logger.Log($"Сессия: {_currentSession.SessionId}");
            Logger.Log($"Группа: {_currentSession.GroupName}, Фамилия: {_currentSession.Surname}");

            _isRunning = true;

            await SyncSessionToDatabase();
            await ProcessSyncQueueAsync();

            if (_enableActivityMonitoring)
            {
                await _activityMonitor.StartAsync(_currentSession.SessionId);
                Logger.Log($"Мониторинг активности: ON ({_activityMonitor.TrackedAppsCount} приложений)");
            }
            else
            {
                Logger.Log("Мониторинг активности: OFF");
            }

            // Удалённые команды — работают всегда (независимо от сессии)
            _remoteCommands.Start();
            Logger.Log("Удалённые команды: ON");

            _updateTimer = new Timer(_updateIntervalMs);
            _updateTimer.Elapsed += async (s, e) => await OnUpdateTimerElapsed();
            _updateTimer.AutoReset = true;
            _updateTimer.Start();

            _syncTimer = new Timer(_syncIntervalMs);
            _syncTimer.Elapsed += async (s, e) => await ProcessSyncQueueAsync();
            _syncTimer.AutoReset = true;
            _syncTimer.Start();

            await UpdateSessionAsync();

            Logger.Log($"Таймеры: обновление {_updateIntervalMs / 1000}с, синхронизация {_syncIntervalMs / 1000}с");
        }

        private async Task SyncSessionToDatabase()
        {
            if (_currentSession == null) return;

            bool ok = await _database.InsertSessionAsync(_currentSession);
            if (!ok)
            {
                _localStorage.SaveToSyncQueue(new SyncQueueItem
                {
                    SessionId = _currentSession.SessionId,
                    ActionType = "INSERT",
                    Data = _currentSession
                });
                Logger.Log("Сессия → очередь синхронизации");
            }
            else
            {
                Logger.Log("Сессия → БД ✓");
            }
        }

        private async Task OnUpdateTimerElapsed()
        {
            if (!_isRunning || _isDisposed) return;
            await UpdateSessionAsync();
        }

        private async Task UpdateSessionAsync()
        {
            lock (_lockObject)
            {
                if (_currentSession == null || !_isRunning) return;
            }

            try
            {
                _currentSession.UpdateDuration();
                DateTime now = DateTime.Now;

                _localStorage.UpdateJournalEntry(
                    _currentSession.SessionId, now, _currentSession.DurationMinutes);

                bool dbOk = await _database.UpdateHeartbeatAsync(
                    _currentSession.SessionId, _currentSession.DurationMinutes);

                if (!dbOk)
                {
                    _localStorage.SaveToSyncQueue(new SyncQueueItem
                    {
                        SessionId = _currentSession.SessionId,
                        ActionType = "UPDATE",
                        Data = _currentSession
                    });
                }

                if (_enableActivityMonitoring)
                {
                    await _activityMonitor.SendActivityHeartbeatsAsync();
                }

                Logger.Log($"Heartbeat: БД={dbOk}, длит={_currentSession.DurationMinutes}м, " +
                           $"активностей={_activityMonitor.ActiveEventsCount}");
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateSession ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Обработка офлайн-очереди
        /// </summary>
        private async Task ProcessSyncQueueAsync()
        {
            var queue = _localStorage.LoadSyncQueue();
            if (queue.Count == 0) return;

            Logger.Log($"Очередь синхронизации: {queue.Count} элементов");

            foreach (var item in queue.ToArray())
            {
                bool success = false;

                try
                {
                    switch (item.ActionType)
                    {
                        // ─── Сессии ───
                        case "INSERT":
                            if (item.Data != null)
                                success = await _database.InsertSessionAsync(item.Data);
                            break;

                        case "UPDATE":
                            if (item.Data != null)
                                success = await _database.UpdateHeartbeatAsync(
                                    item.Data.SessionId, item.Data.DurationMinutes);
                            break;

                        case "CLOSE":
                            if (item.Data != null)
                                success = await _database.CloseSessionAsync(
                                    item.Data.SessionId,
                                    item.Data.LogoutTime ?? DateTime.Now,
                                    item.Data.DurationMinutes,
                                    item.Data.Status);
                            break;

                        // ─── Активности ───
                        case "ACTIVITY_START":
                            if (item.ActivityData != null)
                                success = await _database.InsertActivityAsync(item.ActivityData);
                            break;

                        case "ACTIVITY_END":
                            if (item.ActivityData != null)
                                success = await _database.UpdateActivityEndAsync(item.ActivityData);
                            break;

                        case "ACTIVITY_HEARTBEAT":
                            if (item.ActivityData != null)
                                success = await _database.UpdateActivityHeartbeatAsync(item.ActivityData);
                            break;

                        default:
                            Logger.Log($"Неизвестный тип действия: {item.ActionType}");
                            success = true; // Удаляем неизвестные элементы
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"ProcessSyncQueue ошибка [{item.ActionType}]: {ex.Message}");
                }

                if (success)
                {
                    _localStorage.RemoveFromSyncQueue(item);
                    Logger.Log($"Синхронизирован: {item.ActionType} / {item.SessionId}");
                }
                else
                {
                    item.RetryCount++;
                    if (item.RetryCount >= _maxRetryAttempts)
                    {
                        Logger.Log($"Превышены попытки ({_maxRetryAttempts}): " +
                                   $"{item.ActionType} / {item.SessionId} — удаляю из очереди");
                        _localStorage.RemoveFromSyncQueue(item);
                    }
                    else
                    {
                        // БД недоступна — прекращаем обработку очереди до следующего цикла
                        Logger.Log($"БД недоступна, очередь: попытка {item.RetryCount}/{_maxRetryAttempts}");
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Закрывает сессию (вызывается при shutdown/logoff)
        /// </summary>
        public void CloseSession(string status = "ЗАВЕРШЁН")
        {
            lock (_lockObject)
            {
                if (_currentSession == null) return;

                Logger.Log($"=== Закрытие сессии: {status} ===");

                _isRunning = false;
                _updateTimer?.Stop();
                _syncTimer?.Stop();

                // 1. Останавливаем удалённые команды
                _remoteCommands?.Stop();

                // 2. Закрываем все активности
                if (_enableActivityMonitoring)
                {
                    try
                    {
                        _activityMonitor.CloseAllActivities();
                        _activityMonitor.Stop();
                        Logger.Log("Все активности закрыты");
                    }
                    catch (Exception ex)
                    {
                        Logger.Log($"Ошибка закрытия активностей: {ex.Message}");
                    }
                }

                // 3. Закрываем сессию
                DateTime logoutTime = DateTime.Now;
                _currentSession.LogoutTime = logoutTime;
                _currentSession.UpdateDuration();
                _currentSession.Status = status;

                // Локальный CSV
                bool localOk = _localStorage.CloseJournalEntry(
                    _currentSession.SessionId,
                    logoutTime,
                    _currentSession.DurationMinutes,
                    status);
                Logger.Log($"Локальное закрытие: {localOk}");

                // БД (синхронно!)
                bool dbOk = _database.CloseSessionSync(
                    _currentSession.SessionId,
                    logoutTime,
                    _currentSession.DurationMinutes,
                    status);
                Logger.Log($"БД закрытие: {dbOk}");

                // Очередь, если БД недоступна
                if (!dbOk)
                {
                    _localStorage.SaveToSyncQueue(new SyncQueueItem
                    {
                        SessionId = _currentSession.SessionId,
                        ActionType = "CLOSE",
                        Data = _currentSession
                    });
                    Logger.Log("Закрытие → очередь синхронизации");
                }

                // Удаляем файл сессии
                _localStorage.DeleteSessionFile();

                _currentSession = null;
                Logger.Log("=== Сессия закрыта ===");
            }
        }

        public void Stop()
        {
            _isRunning = false;
            _updateTimer?.Stop();
            _syncTimer?.Stop();
            _activityMonitor?.Stop();
            _remoteCommands?.Stop();
        }

        public void Dispose()
        {
            if (_isDisposed) return;
            _isDisposed = true;
            Stop();
            _updateTimer?.Dispose();
            _syncTimer?.Dispose();
            _activityMonitor?.Dispose();
            _remoteCommands?.Dispose();
        }
    }
}
