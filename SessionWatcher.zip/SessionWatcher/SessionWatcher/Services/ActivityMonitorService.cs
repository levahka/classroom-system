﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using SessionWatcher.Models;

namespace SessionWatcher.Services
{
    /// <summary>
    /// Сервис мониторинга активности: отслеживает запуск игр, лаунчеров, браузерных игр
    /// </summary>
    public class ActivityMonitorService : IDisposable
    {
        #region Win32 API для перебора всех окон

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(IntPtr hWnd);

        #endregion

        // Имена процессов браузеров (без .exe)
        private static readonly HashSet<string> BrowserProcessNames = new HashSet<string>(
            StringComparer.OrdinalIgnoreCase)
        {
            "chrome", "msedge", "firefox", "browser", "opera",
            "yandexbrowser", "iexplore", "vivaldi", "brave"
        };

        private readonly DatabaseService _database;
        private readonly LocalStorageService _localStorage;

        private List<TrackedApp> _trackedApps = new List<TrackedApp>();
        private readonly Dictionary<int, ActivityEvent> _activeEvents = new Dictionary<int, ActivityEvent>();
        // ключ = TrackedApp.Id

        private Timer _scanTimer;
        private Timer _refreshTimer;
        private string _currentSessionId;
        private bool _isRunning;
        private bool _isDisposed;
        private readonly object _lock = new object();

        private readonly int _scanIntervalMs;
        private readonly int _refreshIntervalMs;

        /// <summary>
        /// Вызывается при обнаружении новой активности
        /// </summary>
        public event Action<ActivityEvent> OnActivityStarted;

        /// <summary>
        /// Вызывается при завершении активности
        /// </summary>
        public event Action<ActivityEvent> OnActivityEnded;

        public int TrackedAppsCount => _trackedApps.Count;
        public int ActiveEventsCount => _activeEvents.Count;

        public ActivityMonitorService(DatabaseService database, LocalStorageService localStorage)
        {
            _database = database;
            _localStorage = localStorage;

            int scanSec = 10;
            int refreshMin = 60;
            try
            {
                scanSec = int.Parse(
                    System.Configuration.ConfigurationManager.AppSettings["ActivityScanIntervalSeconds"] ?? "10");
                refreshMin = int.Parse(
                    System.Configuration.ConfigurationManager.AppSettings["TrackedAppsRefreshMinutes"] ?? "60");
            }
            catch { }

            _scanIntervalMs = scanSec * 1000;
            _refreshIntervalMs = refreshMin * 60 * 1000;
        }

        /// <summary>
        /// Запускает мониторинг
        /// </summary>
        public async Task StartAsync(string sessionId)
        {
            if (_isRunning) return;

            _currentSessionId = sessionId;
            Logger.Log("=== ActivityMonitor: запуск ===");

            // Загружаем список отслеживаемых приложений
            await LoadTrackedAppsAsync();
            Logger.Log($"ActivityMonitor: загружено {_trackedApps.Count} приложений для отслеживания");

            _isRunning = true;

            // Таймер сканирования процессов
            _scanTimer = new Timer(_scanIntervalMs);
            _scanTimer.Elapsed += (s, e) => ScanProcesses();
            _scanTimer.AutoReset = true;
            _scanTimer.Start();

            // Таймер обновления списка приложений
            _refreshTimer = new Timer(_refreshIntervalMs);
            _refreshTimer.Elapsed += async (s, e) => await LoadTrackedAppsAsync();
            _refreshTimer.AutoReset = true;
            _refreshTimer.Start();

            // Первое сканирование сразу
            ScanProcesses();

            Logger.Log($"ActivityMonitor: сканирование каждые {_scanIntervalMs / 1000}с, " +
                        $"обновление списка каждые {_refreshIntervalMs / 60000} мин");
        }

        /// <summary>
        /// Загружает (или обновляет) список отслеживаемых приложений
        /// </summary>
        public async Task LoadTrackedAppsAsync()
        {
            try
            {
                // Пытаемся получить с сервера
                var serverApps = await _database.GetTrackedAppsAsync();

                if (serverApps != null && serverApps.Count > 0)
                {
                    _trackedApps = serverApps;
                    _localStorage.CacheTrackedApps(serverApps);
                    Logger.Log($"ActivityMonitor: список обновлён с сервера ({serverApps.Count} записей)");
                }
                else
                {
                    // Используем локальный кэш
                    var cached = _localStorage.LoadCachedTrackedApps();
                    if (cached.Count > 0)
                    {
                        _trackedApps = cached;
                        Logger.Log($"ActivityMonitor: используется локальный кэш ({cached.Count} записей)");
                    }
                    else
                    {
                        Logger.Log("ActivityMonitor: ВНИМАНИЕ — список приложений пуст!");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ActivityMonitor: ошибка загрузки списка — {ex.Message}");
            }
        }

        /// <summary>
        /// Основной цикл сканирования
        /// </summary>
        private void ScanProcesses()
        {
            if (!_isRunning || _isDisposed || _trackedApps.Count == 0)
                return;

            try
            {
                // 1. Собираем информацию обо всех процессах и окнах
                var processInfos = GetRunningProcessInfos();
                var allWindowTitles = GetAllVisibleWindowTitles();

                // 2. Определяем, какие отслеживаемые приложения сейчас активны
                var detectedNow = new Dictionary<int, DetectionResult>();

                foreach (var app in _trackedApps)
                {
                    if (!app.IsActive) continue;

                    var result = DetectApp(app, processInfos, allWindowTitles);
                    if (result != null)
                    {
                        detectedNow[app.Id] = result;
                    }
                }

                // 3. Обрабатываем новые и завершённые активности
                lock (_lock)
                {
                    // Новые активности
                    foreach (var kvp in detectedNow)
                    {
                        int appId = kvp.Key;
                        var result = kvp.Value;

                        if (!_activeEvents.ContainsKey(appId))
                        {
                            // Новое обнаружение!
                            var evt = new ActivityEvent
                            {
                                SessionId = _currentSessionId,
                                ComputerName = Environment.MachineName,
                                TrackedAppId = appId,
                                AppName = result.AppName,
                                ProcessName = result.ProcessName,
                                Category = result.Category,
                                WindowTitle = TruncateString(result.WindowTitle, 450),
                                StartTime = DateTime.Now,
                                IsActive = true,
                                LastSeen = DateTime.Now
                            };

                            _activeEvents[appId] = evt;

                            Logger.Log($"▶ ОБНАРУЖЕНО: {evt.AppName} [{evt.Category}] " +
                                        $"(окно: {evt.WindowTitle ?? "—"})");

                            // Отправляем на сервер
                            Task.Run(() => SendActivityStartAsync(evt));

                            OnActivityStarted?.Invoke(evt);
                        }
                        else
                        {
                            // Обновляем last_seen и заголовок
                            var existing = _activeEvents[appId];
                            existing.LastSeen = DateTime.Now;
                            if (!string.IsNullOrEmpty(result.WindowTitle))
                                existing.WindowTitle = TruncateString(result.WindowTitle, 450);
                        }
                    }

                    // Завершённые активности
                    var endedKeys = _activeEvents.Keys
                        .Where(k => !detectedNow.ContainsKey(k))
                        .ToList();

                    foreach (var appId in endedKeys)
                    {
                        var evt = _activeEvents[appId];
                        evt.MarkEnded();

                        Logger.Log($"■ ЗАВЕРШЕНО: {evt.AppName} [{evt.Category}] " +
                                    $"длительность: {FormatDuration(evt.DurationSeconds)}");

                        // Отправляем на сервер
                        Task.Run(() => SendActivityEndAsync(evt));

                        OnActivityEnded?.Invoke(evt);
                        _activeEvents.Remove(appId);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ActivityMonitor ScanProcesses ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Проверяет, обнаружено ли конкретное приложение
        /// </summary>
        private DetectionResult DetectApp(
            TrackedApp app,
            Dictionary<string, ProcessInfo> processInfos,
            List<WindowInfo> allWindows)
        {
            bool processFound = false;
            string windowTitle = null;

            // --- Обнаружение по процессу ---
            if ((app.DetectionType == "PROCESS" || app.DetectionType == "BOTH")
                && !string.IsNullOrEmpty(app.ProcessNameWithoutExtension))
            {
                ProcessInfo pi;
                if (processInfos.TryGetValue(app.ProcessNameWithoutExtension.ToLowerInvariant(), out pi))
                {
                    processFound = true;
                    windowTitle = pi.MainWindowTitle;
                }
            }

            // Для PROCESS достаточно найти процесс
            if (app.DetectionType == "PROCESS" && processFound)
            {
                return new DetectionResult
                {
                    AppName = app.DisplayName,
                    ProcessName = app.ProcessNameWithoutExtension,
                    Category = app.Category,
                    WindowTitle = windowTitle
                };
            }

            // --- Обнаружение по заголовку окна ---
            if (app.DetectionType == "WINDOW_TITLE" || app.DetectionType == "BOTH")
            {
                if (!string.IsNullOrEmpty(app.TitlePattern))
                {
                    // Для WINDOW_TITLE: ищем среди ВСЕХ окон (в основном браузеры)
                    // Для BOTH: ищем среди окон найденного процесса или всех

                    IEnumerable<WindowInfo> windowsToCheck;

                    if (app.DetectionType == "BOTH" && processFound)
                    {
                        // Проверяем только окна найденного процесса
                        string pName = app.ProcessNameWithoutExtension.ToLowerInvariant();
                        windowsToCheck = allWindows.Where(w =>
                            w.ProcessName != null &&
                            w.ProcessName.Equals(pName, StringComparison.OrdinalIgnoreCase));
                    }
                    else if (app.DetectionType == "WINDOW_TITLE")
                    {
                        // Для браузерных игр — проверяем окна браузеров
                        windowsToCheck = allWindows.Where(w =>
                            w.ProcessName != null &&
                            BrowserProcessNames.Contains(w.ProcessName));
                    }
                    else
                    {
                        windowsToCheck = Enumerable.Empty<WindowInfo>();
                    }

                    foreach (var w in windowsToCheck)
                    {
                        if (!string.IsNullOrEmpty(w.Title) &&
                            w.Title.IndexOf(app.TitlePattern, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            return new DetectionResult
                            {
                                AppName = app.DisplayName,
                                ProcessName = w.ProcessName ?? app.ProcessNameWithoutExtension,
                                Category = app.Category,
                                WindowTitle = w.Title
                            };
                        }
                    }
                }

                // Для BOTH: даже если по заголовку не нашли, но процесс запущен — не считаем
                // (напр. javaw.exe без "Minecraft" в заголовке — это не Minecraft)
            }

            return null;
        }

        #region Сбор информации о процессах и окнах

        /// <summary>
        /// Получает информацию обо всех запущенных процессах
        /// Ключ — имя процесса в нижнем регистре (без .exe)
        /// </summary>
        private Dictionary<string, ProcessInfo> GetRunningProcessInfos()
        {
            var result = new Dictionary<string, ProcessInfo>(StringComparer.OrdinalIgnoreCase);

            try
            {
                foreach (var proc in Process.GetProcesses())
                {
                    try
                    {
                        string name = proc.ProcessName;
                        if (string.IsNullOrEmpty(name)) continue;

                        string key = name.ToLowerInvariant();
                        if (!result.ContainsKey(key))
                        {
                            string title = null;
                            try { title = proc.MainWindowTitle; } catch { }

                            result[key] = new ProcessInfo
                            {
                                ProcessName = name,
                                MainWindowTitle = title,
                                Pid = proc.Id
                            };
                        }
                    }
                    catch { }
                    finally
                    {
                        try { proc.Dispose(); } catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"GetRunningProcessInfos ошибка: {ex.Message}");
            }

            return result;
        }

        /// <summary>
        /// Получает заголовки ВСЕХ видимых окон через Win32 API
        /// </summary>
        private List<WindowInfo> GetAllVisibleWindowTitles()
        {
            var windows = new List<WindowInfo>();

            // Маппинг PID -> имя процесса
            var pidToName = new Dictionary<uint, string>();
            try
            {
                foreach (var proc in Process.GetProcesses())
                {
                    try
                    {
                        pidToName[(uint)proc.Id] = proc.ProcessName;
                    }
                    catch { }
                    finally
                    {
                        try { proc.Dispose(); } catch { }
                    }
                }
            }
            catch { }

            try
            {
                EnumWindows((hWnd, lParam) =>
                {
                    try
                    {
                        if (!IsWindowVisible(hWnd))
                            return true;

                        int length = GetWindowTextLength(hWnd);
                        if (length == 0)
                            return true;

                        var sb = new StringBuilder(length + 1);
                        GetWindowText(hWnd, sb, sb.Capacity);
                        string title = sb.ToString();

                        if (string.IsNullOrWhiteSpace(title))
                            return true;

                        uint pid;
                        GetWindowThreadProcessId(hWnd, out pid);

                        string processName = null;
                        pidToName.TryGetValue(pid, out processName);

                        windows.Add(new WindowInfo
                        {
                            Title = title,
                            ProcessName = processName,
                            Pid = pid
                        });
                    }
                    catch { }

                    return true;
                }, IntPtr.Zero);
            }
            catch (Exception ex)
            {
                Logger.Log($"GetAllVisibleWindowTitles ошибка: {ex.Message}");
            }

            return windows;
        }

        #endregion

        #region Отправка данных на сервер

        /// <summary>
        /// Отправляет начало активности в БД, при ошибке — в очередь синхронизации
        /// </summary>
        private async Task SendActivityStartAsync(ActivityEvent evt)
        {
            try
            {
                bool success = await _database.InsertActivityAsync(evt);
                if (!success)
                {
                    Logger.Log($"ActivityMonitor: не удалось записать старт {evt.AppName} в БД, сохраняю в очередь");
                    _localStorage.SaveToSyncQueue(new SyncQueueItem
                    {
                        SessionId = evt.SessionId,
                        ActionType = "ACTIVITY_START",
                        ActivityData = evt
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"SendActivityStartAsync ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Отправляет завершение активности в БД, при ошибке — в очередь синхронизации
        /// </summary>
        private async Task SendActivityEndAsync(ActivityEvent evt)
        {
            try
            {
                bool success = await _database.UpdateActivityEndAsync(evt);
                if (!success)
                {
                    Logger.Log($"ActivityMonitor: не удалось записать завершение {evt.AppName} в БД, сохраняю в очередь");
                    _localStorage.SaveToSyncQueue(new SyncQueueItem
                    {
                        SessionId = evt.SessionId,
                        ActionType = "ACTIVITY_END",
                        ActivityData = evt
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"SendActivityEndAsync ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Отправляет heartbeat для всех активных событий
        /// </summary>
        public async Task SendActivityHeartbeatsAsync()
        {
            List<ActivityEvent> activeList;
            lock (_lock)
            {
                activeList = _activeEvents.Values.ToList();
            }

            foreach (var evt in activeList)
            {
                try
                {
                    evt.UpdateDuration();
                    evt.LastSeen = DateTime.Now;
                    await _database.UpdateActivityHeartbeatAsync(evt);
                }
                catch (Exception ex)
                {
                    Logger.Log($"SendActivityHeartbeat ошибка для {evt.AppName}: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Закрывает все активные события
        /// </summary>
        public void CloseAllActivities()
        {
            lock (_lock)
            {
                foreach (var kvp in _activeEvents.ToList())
                {
                    var evt = kvp.Value;
                    evt.MarkEnded();

                    Logger.Log($"■ ЗАКРЫТИЕ (стоп): {evt.AppName} [{evt.Category}] " +
                                $"длительность: {FormatDuration(evt.DurationSeconds)}");

                    try
                    {
                        Task.Run(() => SendActivityEndAsync(evt)).Wait(3000);
                    }
                    catch { }

                    OnActivityEnded?.Invoke(evt);
                }

                _activeEvents.Clear();
            }
        }

        #endregion

        /// <summary>
        /// Останавливает мониторинг
        /// </summary>
        public void Stop()
        {
            if (!_isRunning) return;

            _isRunning = false;

            try { _scanTimer?.Stop(); } catch { }
            try { _refreshTimer?.Stop(); } catch { }

            // Закрываем все активные события
            CloseAllActivities();

            Logger.Log("=== ActivityMonitor: остановлен ===");
        }

        #region Вспомогательные классы и методы

        /// <summary>
        /// Обрезает строку до указанной длины
        /// </summary>
        private static string TruncateString(string s, int max)
        {
            if (string.IsNullOrEmpty(s) || s.Length <= max)
                return s;
            return s.Substring(0, max);
        }

        /// <summary>
        /// Форматирует длительность в человеко-читаемый вид
        /// </summary>
        private static string FormatDuration(int seconds)
        {
            if (seconds < 60)
                return $"{seconds}с";
            if (seconds < 3600)
                return $"{seconds / 60}м {seconds % 60}с";
            return $"{seconds / 3600}ч {(seconds % 3600) / 60}м";
        }

        public void Dispose()
        {
            if (_isDisposed) return;
            _isDisposed = true;

            Stop();

            try { _scanTimer?.Dispose(); } catch { }
            try { _refreshTimer?.Dispose(); } catch { }
        }

        #endregion
    }

    /// <summary>
    /// Результат обнаружения приложения
    /// </summary>
    public class DetectionResult
    {
        public string AppName { get; set; }
        public string ProcessName { get; set; }
        public string Category { get; set; }
        public string WindowTitle { get; set; }
    }

    /// <summary>
    /// Информация об окне
    /// </summary>
    public class WindowInfo
    {
        public string Title { get; set; }
        public string ProcessName { get; set; }
        public uint Pid { get; set; }
    }

    /// <summary>
    /// Информация о процессе
    /// </summary>
    public class ProcessInfo
    {
        public string ProcessName { get; set; }
        public string MainWindowTitle { get; set; }
        public int Pid { get; set; }
    }
}
