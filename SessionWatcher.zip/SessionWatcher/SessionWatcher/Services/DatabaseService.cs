﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using SessionWatcher.Models;

namespace SessionWatcher.Services
{
    /// <summary>
    /// Сервис для работы с MySQL базой данных
    /// </summary>
    public class DatabaseService
    {
        private readonly string _connectionString;
        private bool _isConnected = false;
        private DateTime _lastConnectionCheck = DateTime.MinValue;
        private readonly TimeSpan _connectionCheckInterval = TimeSpan.FromSeconds(30);

        public bool IsConnected => _isConnected;
        public event Action<bool> ConnectionStateChanged;

        /// <summary>
        /// Создать новое подключение к БД (для RemoteCommandService)
        /// </summary>
        public MySqlConnection CreateConnection()
        {
            return new MySqlConnection(_connectionString);
        }

        public DatabaseService()
        {
            _connectionString = BuildConnectionString();
        }

        private string BuildConnectionString()
        {
            try
            {
                string server = ConfigurationManager.AppSettings["MySqlServer"] ?? "MySQL-8.4";
                string port = ConfigurationManager.AppSettings["MySqlPort"] ?? "3306";
                string database = ConfigurationManager.AppSettings["MySqlDatabase"] ?? "classroom_db";
                string user = ConfigurationManager.AppSettings["MySqlUser"] ?? "classroom_user";
                string password = ConfigurationManager.AppSettings["MySqlPassword"] ?? "";
                string timeout = ConfigurationManager.AppSettings["MySqlConnectionTimeout"] ?? "3";

                return $"Server={server};Port={port};Database={database};Uid={user};Pwd={password};" +
                       $"Connection Timeout={timeout};CharSet=utf8mb4;";
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Проверяет подключение к БД
        /// </summary>
        public async Task<bool> CheckConnectionAsync()
        {
            if (string.IsNullOrEmpty(_connectionString))
                return false;

            // Кэшируем результат проверки
            if (DateTime.Now - _lastConnectionCheck < _connectionCheckInterval && _isConnected)
                return true;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    _isConnected = true;
                    _lastConnectionCheck = DateTime.Now;
                    ConnectionStateChanged?.Invoke(true);
                    return true;
                }
            }
            catch
            {
                bool wasConnected = _isConnected;
                _isConnected = false;
                if (wasConnected)
                    ConnectionStateChanged?.Invoke(false);
                return false;
            }
        }

        /// <summary>
        /// Создаёт новую сессию в БД
        /// </summary>
        public async Task<bool> InsertSessionAsync(SessionData session)
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        INSERT INTO sessions 
                        (session_id, computer_name, group_name, surname, login_time, 
                         status, computer_problem, last_heartbeat, ip_address)
                        VALUES 
                        (@sessionId, @computerName, @groupName, @surname, @loginTime,
                         @status, @computerProblem, @lastHeartbeat, @ipAddress)
                        ON DUPLICATE KEY UPDATE
                         last_heartbeat = @lastHeartbeat,
                         status = @status";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", session.SessionId);
                        cmd.Parameters.AddWithValue("@computerName", session.ComputerName);
                        cmd.Parameters.AddWithValue("@groupName", session.GroupName ?? "");
                        cmd.Parameters.AddWithValue("@surname", session.Surname ?? "");
                        cmd.Parameters.AddWithValue("@loginTime", session.LoginTime);
                        cmd.Parameters.AddWithValue("@status", session.Status);
                        cmd.Parameters.AddWithValue("@computerProblem", session.ComputerProblem ?? "OK");
                        cmd.Parameters.AddWithValue("@lastHeartbeat", DateTime.Now);
                        cmd.Parameters.AddWithValue("@ipAddress", session.IpAddress ?? "");

                        await cmd.ExecuteNonQueryAsync();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.Log($"InsertSession ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Обновляет heartbeat и длительность сессии
        /// </summary>
        public async Task<bool> UpdateHeartbeatAsync(string sessionId, int durationMinutes)
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        UPDATE sessions 
                        SET last_heartbeat = @now, 
                            duration_minutes = @duration
                        WHERE session_id = @sessionId AND status = 'АКТИВЕН'";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.Parameters.AddWithValue("@now", DateTime.Now);
                        cmd.Parameters.AddWithValue("@duration", durationMinutes);

                        int affected = await cmd.ExecuteNonQueryAsync();
                        return affected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateHeartbeat ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Закрывает сессию
        /// </summary>
        public async Task<bool> CloseSessionAsync(string sessionId, DateTime logoutTime,
            int durationMinutes, string status = "ЗАВЕРШЁН")
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        UPDATE sessions 
                        SET logout_time = @logoutTime,
                            duration_minutes = @duration,
                            status = @status,
                            last_heartbeat = @logoutTime
                        WHERE session_id = @sessionId";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.Parameters.AddWithValue("@logoutTime", logoutTime);
                        cmd.Parameters.AddWithValue("@duration", durationMinutes);
                        cmd.Parameters.AddWithValue("@status", status);

                        int affected = await cmd.ExecuteNonQueryAsync();
                        return affected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"CloseSession ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Синхронная версия закрытия
        /// </summary>
        public bool CloseSessionSync(string sessionId, DateTime logoutTime,
            int durationMinutes, string status = "ЗАВЕРШЁН")
        {
            if (string.IsNullOrEmpty(_connectionString))
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = @"
                        UPDATE sessions 
                        SET logout_time = @logoutTime,
                            duration_minutes = @duration,
                            status = @status,
                            last_heartbeat = @logoutTime
                        WHERE session_id = @sessionId";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.Parameters.AddWithValue("@logoutTime", logoutTime);
                        cmd.Parameters.AddWithValue("@duration", durationMinutes);
                        cmd.Parameters.AddWithValue("@status", status);

                        cmd.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.Log($"CloseSessionSync ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Получает сессии с сервера для указанного компьютера
        /// </summary>
        public async Task<List<ServerSessionInfo>> GetSessionsForComputerAsync(string computerName)
        {
            var sessions = new List<ServerSessionInfo>();

            if (!await CheckConnectionAsync())
                return sessions;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    // Получаем сессии за последние 7 дней для этого компьютера
                    string query = @"
                        SELECT session_id, status, logout_time, duration_minutes, last_heartbeat
                        FROM sessions 
                        WHERE computer_name = @computerName 
                          AND login_time > DATE_SUB(NOW(), INTERVAL 7 DAY)";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@computerName", computerName);

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            // Получаем индексы один раз
                            int idxSessionId = reader.GetOrdinal("session_id");
                            int idxStatus = reader.GetOrdinal("status");
                            int idxLogoutTime = reader.GetOrdinal("logout_time");
                            int idxDuration = reader.GetOrdinal("duration_minutes");
                            int idxHeartbeat = reader.GetOrdinal("last_heartbeat");

                            while (await reader.ReadAsync())
                            {
                                sessions.Add(new ServerSessionInfo
                                {
                                    SessionId = reader.GetString(idxSessionId),
                                    Status = reader.GetString(idxStatus),
                                    LogoutTime = reader.IsDBNull(idxLogoutTime)
                                        ? (DateTime?)null
                                        : reader.GetDateTime(idxLogoutTime),
                                    DurationMinutes = reader.GetInt32(idxDuration),
                                    LastHeartbeat = reader.IsDBNull(idxHeartbeat)
                                        ? (DateTime?)null
                                        : reader.GetDateTime(idxHeartbeat)
                                });
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"GetSessionsForComputer ошибка: {ex.Message}");
            }

            return sessions;
        }

        /// <summary>
        /// Обновляет статус сессии на сервере
        /// </summary>
        public async Task<bool> UpdateSessionStatusAsync(string sessionId, string status,
            DateTime? logoutTime = null, int? durationMinutes = null)
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        UPDATE sessions 
                        SET status = @status";

                    if (logoutTime.HasValue)
                        query += ", logout_time = @logoutTime";

                    if (durationMinutes.HasValue)
                        query += ", duration_minutes = @duration";

                    query += " WHERE session_id = @sessionId";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);
                        cmd.Parameters.AddWithValue("@status", status);

                        if (logoutTime.HasValue)
                            cmd.Parameters.AddWithValue("@logoutTime", logoutTime.Value);

                        if (durationMinutes.HasValue)
                            cmd.Parameters.AddWithValue("@duration", durationMinutes.Value);

                        int affected = await cmd.ExecuteNonQueryAsync();
                        return affected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateSessionStatus ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Получает статус сессии с сервера
        /// </summary>
        public async Task<ServerSessionInfo> GetSessionInfoAsync(string sessionId)
        {
            if (!await CheckConnectionAsync())
                return null;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        SELECT session_id, status, logout_time, duration_minutes, last_heartbeat
                        FROM sessions 
                        WHERE session_id = @sessionId";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@sessionId", sessionId);

                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                // Получаем индексы столбцов
                                int idxSessionId = reader.GetOrdinal("session_id");
                                int idxStatus = reader.GetOrdinal("status");
                                int idxLogoutTime = reader.GetOrdinal("logout_time");
                                int idxDuration = reader.GetOrdinal("duration_minutes");
                                int idxHeartbeat = reader.GetOrdinal("last_heartbeat");

                                return new ServerSessionInfo
                                {
                                    SessionId = reader.GetString(idxSessionId),
                                    Status = reader.GetString(idxStatus),
                                    LogoutTime = reader.IsDBNull(idxLogoutTime)
                                        ? (DateTime?)null
                                        : reader.GetDateTime(idxLogoutTime),
                                    DurationMinutes = reader.GetInt32(idxDuration),
                                    LastHeartbeat = reader.IsDBNull(idxHeartbeat)
                                        ? (DateTime?)null
                                        : reader.GetDateTime(idxHeartbeat)
                                };
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.Log($"GetSessionInfo ошибка: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Получает список активных отслеживаемых приложений
        /// </summary>
        public async Task<List<TrackedApp>> GetTrackedAppsAsync()
        {
            var apps = new List<TrackedApp>();

            if (!await CheckConnectionAsync())
                return apps;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        SELECT id, process_name, display_name, category, 
                               detection_type, title_pattern, is_active, updated_at
                        FROM tracked_apps 
                        WHERE is_active = TRUE";

                    using (var cmd = new MySqlCommand(query, connection))
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        int idxId = reader.GetOrdinal("id");
                        int idxProcess = reader.GetOrdinal("process_name");
                        int idxDisplay = reader.GetOrdinal("display_name");
                        int idxCat = reader.GetOrdinal("category");
                        int idxDetect = reader.GetOrdinal("detection_type");
                        int idxTitle = reader.GetOrdinal("title_pattern");
                        int idxActive = reader.GetOrdinal("is_active");
                        int idxUpdated = reader.GetOrdinal("updated_at");

                        while (await reader.ReadAsync())
                        {
                            apps.Add(new TrackedApp
                            {
                                Id = reader.GetInt32(idxId),
                                ProcessName = reader.IsDBNull(idxProcess)
                                    ? null : reader.GetString(idxProcess),
                                DisplayName = reader.GetString(idxDisplay),
                                Category = reader.GetString(idxCat),
                                DetectionType = reader.GetString(idxDetect),
                                TitlePattern = reader.IsDBNull(idxTitle)
                                    ? null : reader.GetString(idxTitle),
                                IsActive = reader.GetBoolean(idxActive),
                                UpdatedAt = reader.GetDateTime(idxUpdated)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"GetTrackedApps ошибка: {ex.Message}");
            }

            return apps;
        }

        /// <summary>
        /// Вставляет запись активности в БД
        /// </summary>
        public async Task<bool> InsertActivityAsync(ActivityEvent evt)
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        INSERT INTO activity_log 
                        (activity_id, session_id, computer_name, tracked_app_id, app_name, process_name,
                         category, window_title, start_time, is_active, last_seen)
                        VALUES 
                        (@activityId, @sessionId, @computerName, @trackedAppId, @appName, @processName,
                         @category, @windowTitle, @startTime, @isActive, @lastSeen)
                        ON DUPLICATE KEY UPDATE
                         last_seen = @lastSeen, is_active = @isActive";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@activityId", evt.ActivityId);
                        cmd.Parameters.AddWithValue("@sessionId", evt.SessionId);
                        cmd.Parameters.AddWithValue("@computerName", evt.ComputerName);
                        cmd.Parameters.AddWithValue("@trackedAppId",
                            evt.TrackedAppId.HasValue ? (object)evt.TrackedAppId.Value : DBNull.Value);
                        cmd.Parameters.AddWithValue("@appName", evt.AppName);
                        cmd.Parameters.AddWithValue("@processName",
                            (object)evt.ProcessName ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@category", evt.Category);
                        cmd.Parameters.AddWithValue("@windowTitle",
                            (object)evt.WindowTitle ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@startTime", evt.StartTime);
                        cmd.Parameters.AddWithValue("@isActive", evt.IsActive);
                        cmd.Parameters.AddWithValue("@lastSeen", evt.LastSeen);

                        await cmd.ExecuteNonQueryAsync();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.Log($"InsertActivity ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Обновляет завершение активности в БД
        /// </summary>
        public async Task<bool> UpdateActivityEndAsync(ActivityEvent evt)
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        UPDATE activity_log 
                        SET end_time = @endTime,
                            duration_seconds = @duration,
                            is_active = FALSE,
                            last_seen = @lastSeen
                        WHERE activity_id = @activityId";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@activityId", evt.ActivityId);
                        cmd.Parameters.AddWithValue("@endTime", evt.EndTime ?? DateTime.Now);
                        cmd.Parameters.AddWithValue("@duration", evt.DurationSeconds);
                        cmd.Parameters.AddWithValue("@lastSeen", evt.LastSeen);

                        int affected = await cmd.ExecuteNonQueryAsync();
                        return affected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateActivityEnd ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Обновляет heartbeat активности (last_seen и duration)
        /// </summary>
        public async Task<bool> UpdateActivityHeartbeatAsync(ActivityEvent evt)
        {
            if (!await CheckConnectionAsync())
                return false;

            try
            {
                using (var connection = new MySqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    string query = @"
                        UPDATE activity_log 
                        SET last_seen = @lastSeen,
                            duration_seconds = @duration
                        WHERE activity_id = @activityId AND is_active = TRUE";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@activityId", evt.ActivityId);
                        cmd.Parameters.AddWithValue("@lastSeen", evt.LastSeen);
                        cmd.Parameters.AddWithValue("@duration", evt.DurationSeconds);

                        int affected = await cmd.ExecuteNonQueryAsync();
                        return affected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateActivityHeartbeat ошибка: {ex.Message}");
                return false;
            }
        }
    }

    /// <summary>
    /// Информация о сессии с сервера
    /// </summary>
    public class ServerSessionInfo
    {
        public string SessionId { get; set; }
        public string Status { get; set; }
        public DateTime? LogoutTime { get; set; }
        public int DurationMinutes { get; set; }
        public DateTime? LastHeartbeat { get; set; }

        public bool IsActive => Status == "АКТИВЕН";
    }
}
