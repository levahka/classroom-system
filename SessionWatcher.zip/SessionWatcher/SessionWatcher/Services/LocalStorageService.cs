﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using SessionWatcher.Models;

namespace SessionWatcher.Services
{
    /// <summary>
    /// Сервис для работы с локальными файлами
    /// </summary>
    public class LocalStorageService
    {
        private readonly string _logFolder;
        private readonly string _journalPath;
        private readonly string _sessionFilePath;
        private readonly string _syncQueuePath;
        private readonly int _maxJournalRecords;

        public string JournalPath => _journalPath;
        public string SessionFilePath => _sessionFilePath;

        public LocalStorageService()
        {
            _logFolder = ConfigurationManager.AppSettings["LogFolder"] ?? @"C:\ClassroomLog";
            _journalPath = Path.Combine(_logFolder, "journal.csv");
            _sessionFilePath = Path.Combine(_logFolder, "current_session.txt");
            _syncQueuePath = Path.Combine(_logFolder, "sync_queue.json");
            _maxJournalRecords = int.Parse(ConfigurationManager.AppSettings["MaxJournalRecords"] ?? "50");

            EnsureDirectoryExists();
        }

        private void EnsureDirectoryExists()
        {
            try
            {
                Directory.CreateDirectory(_logFolder);
            }
            catch (Exception ex)
            {
                Logger.Log($"Ошибка создания папки: {ex.Message}");
            }
        }

        /// <summary>
        /// Проверяет существование файла сессии
        /// </summary>
        public bool SessionFileExists()
        {
            return File.Exists(_sessionFilePath);
        }

        /// <summary>
        /// Читает данные текущей сессии
        /// </summary>
        public SessionData ReadCurrentSession()
        {
            try
            {
                Logger.Log($"Проверяю файл: {_sessionFilePath}");

                if (!File.Exists(_sessionFilePath))
                {
                    Logger.Log("Файл сессии НЕ существует!");
                    return null;
                }

                string sessionContent = File.ReadAllText(_sessionFilePath, Encoding.UTF8);
                Logger.Log($"Содержимое файла: [{sessionContent}]");

                if (string.IsNullOrWhiteSpace(sessionContent))
                {
                    Logger.Log("Файл сессии ПУСТОЙ!");
                    return null;
                }

                // Ищем соответствующую строку в CSV для получения полных данных
                string csvLine = null;
                var parts = sessionContent.Split('|');
                if (parts.Length >= 1 && File.Exists(_journalPath))
                {
                    string sessionId = parts[0].Trim();
                    var lines = File.ReadAllLines(_journalPath, Encoding.UTF8);
                    csvLine = lines.FirstOrDefault(l => l.StartsWith(sessionId + ";"));
                }

                var result = SessionData.FromSessionFile(sessionContent, csvLine);

                if (result == null)
                {
                    Logger.Log("FromSessionFile вернул NULL - неверный формат!");
                }
                else
                {
                    Logger.Log($"Сессия распознана: {result.SessionId}");
                }

                return result;
            }
            catch (Exception ex)
            {
                Logger.Log($"ReadCurrentSession ИСКЛЮЧЕНИЕ: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Читает все записи из журнала CSV
        /// </summary>
        public List<JournalEntry> ReadAllJournalEntries()
        {
            var entries = new List<JournalEntry>();

            try
            {
                if (!File.Exists(_journalPath))
                    return entries;

                var lines = File.ReadAllLines(_journalPath, Encoding.UTF8);

                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    // Пропускаем заголовок если есть
                    if (line.StartsWith("SessionId;") || line.StartsWith("ID;"))
                        continue;

                    var entry = JournalEntry.FromCsvLine(line);
                    if (entry != null)
                    {
                        entries.Add(entry);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"ReadAllJournalEntries ошибка: {ex.Message}");
            }

            return entries;
        }

        /// <summary>
        /// Обновляет статус записи в журнале
        /// </summary>
        public bool UpdateJournalEntryStatus(string sessionId, string newStatus,
            DateTime? logoutTime = null, int? durationMinutes = null)
        {
            try
            {
                if (!File.Exists(_journalPath))
                    return false;

                var lines = File.ReadAllLines(_journalPath, Encoding.UTF8).ToList();
                bool found = false;

                for (int i = 0; i < lines.Count; i++)
                {
                    if (lines[i].StartsWith(sessionId + ";"))
                    {
                        var columns = lines[i].Split(';');
                        if (columns.Length >= 9)
                        {
                            // Обновляем статус
                            columns[8] = newStatus;

                            // Обновляем время выхода если передано
                            if (logoutTime.HasValue)
                            {
                                columns[6] = logoutTime.Value.ToString("HH:mm:ss");
                            }

                            // Обновляем длительность если передана
                            if (durationMinutes.HasValue)
                            {
                                columns[7] = durationMinutes.Value.ToString();
                            }

                            lines[i] = string.Join(";", columns);
                            found = true;
                        }
                        break;
                    }
                }

                if (found)
                {
                    File.WriteAllLines(_journalPath, lines, Encoding.UTF8);
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateJournalEntryStatus ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Обновляет запись в журнале
        /// </summary>
        public bool UpdateJournalEntry(string sessionId, DateTime lastActivity, int durationMinutes)
        {
            try
            {
                if (!File.Exists(_journalPath))
                    return false;

                var lines = File.ReadAllLines(_journalPath, Encoding.UTF8).ToList();
                bool found = false;

                for (int i = 0; i < lines.Count; i++)
                {
                    if (lines[i].StartsWith(sessionId + ";"))
                    {
                        var columns = lines[i].Split(';');
                        if (columns.Length >= 9)
                        {
                            columns[6] = lastActivity.ToString("HH:mm:ss");
                            columns[7] = durationMinutes.ToString();
                            lines[i] = string.Join(";", columns);
                            found = true;
                        }
                        break;
                    }
                }

                if (found)
                {
                    File.WriteAllLines(_journalPath, lines, Encoding.UTF8);
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Logger.Log($"UpdateJournalEntry ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Закрывает сессию в журнале
        /// </summary>
        public bool CloseJournalEntry(string sessionId, DateTime logoutTime,
            int durationMinutes, string status)
        {
            try
            {
                if (!File.Exists(_journalPath))
                    return false;

                var lines = File.ReadAllLines(_journalPath, Encoding.UTF8).ToList();
                bool found = false;

                for (int i = 0; i < lines.Count; i++)
                {
                    if (lines[i].StartsWith(sessionId + ";"))
                    {
                        var columns = lines[i].Split(';');
                        if (columns.Length >= 9)
                        {
                            columns[6] = logoutTime.ToString("HH:mm:ss");
                            columns[7] = durationMinutes.ToString();
                            columns[8] = status;
                            lines[i] = string.Join(";", columns);
                            found = true;
                        }
                        break;
                    }
                }

                if (found)
                {
                    File.WriteAllLines(_journalPath, lines, Encoding.UTF8);
                }

                return found;
            }
            catch (Exception ex)
            {
                Logger.Log($"CloseJournalEntry ошибка: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Ограничивает количество записей в журнале (удаляет старые)
        /// </summary>
        public void TrimJournalToMaxRecords()
        {
            try
            {
                if (!File.Exists(_journalPath))
                    return;

                var lines = File.ReadAllLines(_journalPath, Encoding.UTF8).ToList();

                // Проверяем, есть ли заголовок
                bool hasHeader = false;
                string headerLine = null;

                if (lines.Count > 0 && (lines[0].StartsWith("SessionId;") || lines[0].StartsWith("ID;")))
                {
                    hasHeader = true;
                    headerLine = lines[0];
                    lines.RemoveAt(0);
                }

                // Если записей больше максимума - удаляем старые
                if (lines.Count > _maxJournalRecords)
                {
                    int toRemove = lines.Count - _maxJournalRecords;
                    Logger.Log($"Удаляю {toRemove} старых записей из журнала (макс: {_maxJournalRecords})");

                    // Удаляем старые записи (они в начале файла)
                    lines = lines.Skip(toRemove).ToList();

                    // Собираем файл обратно
                    var resultLines = new List<string>();
                    if (hasHeader && headerLine != null)
                    {
                        resultLines.Add(headerLine);
                    }
                    resultLines.AddRange(lines);

                    File.WriteAllLines(_journalPath, resultLines, Encoding.UTF8);
                    Logger.Log($"Журнал сокращён до {lines.Count} записей");
                }
            }
            catch (Exception ex)
            {
                Logger.Log($"TrimJournalToMaxRecords ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Удаляет файл сессии
        /// </summary>
        public void DeleteSessionFile()
        {
            try
            {
                if (File.Exists(_sessionFilePath))
                    File.Delete(_sessionFilePath);
            }
            catch (Exception ex)
            {
                Logger.Log($"DeleteSessionFile ошибка: {ex.Message}");
            }
        }

        #region Кэш отслеживаемых приложений

        /// <summary>
        /// Сохраняет список приложений в локальный кэш (JSON)
        /// </summary>
        public void CacheTrackedApps(List<TrackedApp> apps)
        {
            try
            {
                string cachePath = Path.Combine(_logFolder, "tracked_apps_cache.json");
                string json = Newtonsoft.Json.JsonConvert.SerializeObject(apps,
                    Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(cachePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Logger.Log($"CacheTrackedApps ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Загружает кэшированный список приложений
        /// </summary>
        public List<TrackedApp> LoadCachedTrackedApps()
        {
            try
            {
                string cachePath = Path.Combine(_logFolder, "tracked_apps_cache.json");
                if (!File.Exists(cachePath))
                    return new List<TrackedApp>();

                string json = File.ReadAllText(cachePath, Encoding.UTF8);
                return Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrackedApp>>(json)
                    ?? new List<TrackedApp>();
            }
            catch (Exception ex)
            {
                Logger.Log($"LoadCachedTrackedApps ошибка: {ex.Message}");
                return new List<TrackedApp>();
            }
        }

        #endregion

        #region Очередь синхронизации

        /// <summary>
        /// Сохраняет элемент в очередь синхронизации
        /// </summary>
        public void SaveToSyncQueue(SyncQueueItem item)
        {
            try
            {
                var queue = LoadSyncQueue();

                queue.RemoveAll(q => q.SessionId == item.SessionId && q.ActionType == item.ActionType);
                queue.Add(item);

                string json = Newtonsoft.Json.JsonConvert.SerializeObject(queue,
                    Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(_syncQueuePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Logger.Log($"SaveToSyncQueue ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Загружает очередь синхронизации
        /// </summary>
        public List<SyncQueueItem> LoadSyncQueue()
        {
            try
            {
                if (!File.Exists(_syncQueuePath))
                    return new List<SyncQueueItem>();

                string json = File.ReadAllText(_syncQueuePath, Encoding.UTF8);
                return Newtonsoft.Json.JsonConvert.DeserializeObject<List<SyncQueueItem>>(json)
                    ?? new List<SyncQueueItem>();
            }
            catch
            {
                return new List<SyncQueueItem>();
            }
        }

        /// <summary>
        /// Удаляет элемент из очереди
        /// </summary>
        public void RemoveFromSyncQueue(SyncQueueItem item)
        {
            try
            {
                var queue = LoadSyncQueue();
                queue.RemoveAll(q => q.SessionId == item.SessionId && q.ActionType == item.ActionType);

                string json = Newtonsoft.Json.JsonConvert.SerializeObject(queue,
                    Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(_syncQueuePath, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Logger.Log($"RemoveFromSyncQueue ошибка: {ex.Message}");
            }
        }

        /// <summary>
        /// Очищает очередь синхронизации
        /// </summary>
        public void ClearSyncQueue()
        {
            try
            {
                if (File.Exists(_syncQueuePath))
                    File.Delete(_syncQueuePath);
            }
            catch { }
        }

        #endregion
    }

    /// <summary>
    /// Запись из CSV-журнала
    /// </summary>
    public class JournalEntry
    {
        public string SessionId { get; set; }
        public string Date { get; set; }
        public string GroupName { get; set; }
        public string Surname { get; set; }
        public string ComputerName { get; set; }
        public string LoginTime { get; set; }
        public string LogoutTime { get; set; }
        public string Duration { get; set; }
        public string Status { get; set; }
        public string Problem { get; set; }

        /// <summary>
        /// Парсит строку CSV формата:
        /// SessionId;Date;GroupName;Surname;ComputerName;LoginTime;LogoutTime;Duration;Status;Problem
        /// </summary>
        public static JournalEntry FromCsvLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line))
                return null;

            var parts = line.Split(';');
            if (parts.Length < 9)
                return null;

            return new JournalEntry
            {
                SessionId = parts[0].Trim(),
                Date = parts[1].Trim(),
                GroupName = parts[2].Trim(),
                Surname = parts[3].Trim(),
                ComputerName = parts[4].Trim(),
                LoginTime = parts[5].Trim(),
                LogoutTime = parts[6].Trim(),
                Duration = parts[7].Trim(),
                Status = parts[8].Trim(),
                Problem = parts.Length > 9 ? parts[9].Trim() : ""
            };
        }
    }
}
