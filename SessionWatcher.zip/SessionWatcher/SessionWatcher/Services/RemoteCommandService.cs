﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Timers;
using MySql.Data.MySqlClient;

namespace SessionWatcher.Services
{
    /// <summary>
    /// Сервис удалённых команд — работает ТОЛЬКО через БД (без HTTP).
    /// Опрашивает таблицу remote_commands каждые 10 сек,
    /// выполняет команды и пишет результат обратно в БД.
    /// </summary>
    public class RemoteCommandService : IDisposable
    {
        private readonly DatabaseService _db;
        private readonly string _computerName;
        private Timer _pollTimer;
        private bool _isRunning;
        private bool _isDisposed;

        public event Action<string> OnLog;

        public RemoteCommandService(DatabaseService db, string computerName)
        {
            _db = db;
            _computerName = computerName;
        }

        public void Start()
        {
            if (_isRunning) return;
            _isRunning = true;

            int pollSec = 10;
            try
            {
                pollSec = int.Parse(
                    System.Configuration.ConfigurationManager.AppSettings["CommandPollIntervalSeconds"] ?? "10");
            }
            catch { }

            _pollTimer = new Timer(pollSec * 1000);
            _pollTimer.Elapsed += async (s, e) => await PollAndExecuteAsync();
            _pollTimer.AutoReset = true;
            _pollTimer.Start();

            Log($"Запущен, опрос каждые {pollSec}с");

            // Первый опрос сразу
            Task.Run(() => PollAndExecuteAsync());
        }

        private async Task PollAndExecuteAsync()
        {
            if (!_isRunning || _isDisposed || !_db.IsConnected) return;

            try
            {
                var commands = await GetPendingCommandsAsync();
                foreach (var cmd in commands)
                {
                    await ExecuteAndReportAsync(cmd);
                }
            }
            catch (Exception ex)
            {
                Log($"Ошибка опроса: {ex.Message}");
            }
        }

        /// <summary>
        /// SELECT pending команд из БД
        /// </summary>
        private async Task<List<RemoteCommand>> GetPendingCommandsAsync()
        {
            var result = new List<RemoteCommand>();

            try
            {
                using (var conn = _db.CreateConnection())
                {
                    await conn.OpenAsync();

                    // Автоистечение старых команд (> 5 минут)
                    using (var expireCmd = new MySqlCommand(
                        @"UPDATE remote_commands 
                          SET status='EXPIRED' 
                          WHERE status='PENDING' 
                          AND TIMESTAMPDIFF(SECOND, created_at, NOW()) > 300", conn))
                    {
                        await expireCmd.ExecuteNonQueryAsync();
                    }

                    // Получаем pending для нашего ПК
                    using (var selectCmd = new MySqlCommand(
                        @"SELECT id, command_type, target 
                          FROM remote_commands 
                          WHERE computer_name = @computer AND status = 'PENDING'
                          ORDER BY created_at ASC", conn))
                    {
                        selectCmd.Parameters.AddWithValue("@computer", _computerName);

                        using (var reader = await selectCmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                result.Add(new RemoteCommand
                                {
                                    Id = Convert.ToInt32(reader["id"]),
                                    CommandType = reader["command_type"].ToString(),
                                    Target = reader["target"].ToString()
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"Ошибка чтения команд: {ex.Message}");
            }

            return result;
        }

        /// <summary>
        /// Выполнить команду и записать результат в БД
        /// </summary>
        private async Task ExecuteAndReportAsync(RemoteCommand cmd)
        {
            string resultMsg;
            string status;

            try
            {
                switch (cmd.CommandType)
                {
                    case "KILL_PROCESS":
                        resultMsg = KillByProcessName(cmd.Target);
                        status = "EXECUTED";
                        break;

                    case "KILL_BY_TITLE":
                        resultMsg = KillByWindowTitle(cmd.Target);
                        status = "EXECUTED";
                        break;

                    default:
                        resultMsg = $"Неизвестный тип: {cmd.CommandType}";
                        status = "FAILED";
                        break;
                }
            }
            catch (Exception ex)
            {
                resultMsg = $"Исключение: {ex.Message}";
                status = "FAILED";
            }

            Log($"{cmd.CommandType} '{cmd.Target}' → {status}: {resultMsg}");

            // Записываем результат в БД
            try
            {
                using (var conn = _db.CreateConnection())
                {
                    await conn.OpenAsync();
                    using (var updateCmd = new MySqlCommand(
                        @"UPDATE remote_commands 
                          SET status=@status, executed_at=NOW(), result=@result 
                          WHERE id=@id", conn))
                    {
                        updateCmd.Parameters.AddWithValue("@status", status);
                        updateCmd.Parameters.AddWithValue("@result", resultMsg);
                        updateCmd.Parameters.AddWithValue("@id", cmd.Id);
                        await updateCmd.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"Ошибка записи результата: {ex.Message}");
            }
        }

        /// <summary>
        /// Завершить процесс по имени
        /// </summary>
        private string KillByProcessName(string processName)
        {
            string name = processName
                .Replace(".exe", "").Replace(".EXE", "")
                .Trim();

            var processes = Process.GetProcessesByName(name);
            if (processes.Length == 0)
                return $"Процесс '{name}' не найден";

            int killed = 0, failed = 0;
            foreach (var proc in processes)
            {
                try
                {
                    proc.Kill();
                    proc.WaitForExit(3000);
                    killed++;
                }
                catch
                {
                    failed++;
                }
                finally
                {
                    proc.Dispose();
                }
            }

            return $"Завершено {killed}/{killed + failed} '{name}'";
        }

        /// <summary>
        /// Завершить по заголовку окна (частичное совпадение)
        /// </summary>
        private string KillByWindowTitle(string titlePattern)
        {
            int killed = 0;
            var checkedPids = new HashSet<int>();

            foreach (var proc in Process.GetProcesses())
            {
                try
                {
                    if (checkedPids.Contains(proc.Id)) continue;
                    checkedPids.Add(proc.Id);

                    string title = null;
                    try { title = proc.MainWindowTitle; } catch { continue; }

                    if (!string.IsNullOrEmpty(title) &&
                        title.IndexOf(titlePattern, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        proc.Kill();
                        proc.WaitForExit(3000);
                        killed++;
                    }
                }
                catch { }
                finally
                {
                    proc.Dispose();
                }
            }

            return killed > 0
                ? $"Завершено {killed} с заголовком '{titlePattern}'"
                : $"Окна с '{titlePattern}' не найдены";
        }

        private void Log(string msg)
        {
            string text = $"[RemoteCmd] {msg}";
            Logger.Log(text);
            OnLog?.Invoke(text);
        }

        public void Stop()
        {
            _isRunning = false;
            _pollTimer?.Stop();
            Log("Остановлен");
        }

        public void Dispose()
        {
            if (_isDisposed) return;
            _isDisposed = true;
            Stop();
            _pollTimer?.Dispose();
        }
    }

    public class RemoteCommand
    {
        public int Id { get; set; }
        public string CommandType { get; set; }
        public string Target { get; set; }
    }
}
