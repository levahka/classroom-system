﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using SessionWatcher.Services;

namespace SessionWatcher
{
    /// <summary>
    /// Скрытая форма для перехвата системных сообщений Windows
    /// </summary>
    public class HiddenForm : Form
    {
        private SessionManager _sessionManager;
        private NotifyIcon _trayIcon;
        private bool _isClosing;

        private const int WM_QUERYENDSESSION = 0x0011;
        private const int WM_ENDSESSION = 0x0016;
        private const int WM_POWERBROADCAST = 0x0218;
        private const int PBT_APMSUSPEND = 0x0004;
        private const int PBT_APMRESUMESUSPEND = 0x0007;

        public HiddenForm()
        {
            InitializeForm();
            InitializeTrayIcon();
        }

        private void InitializeForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = false;
            this.WindowState = FormWindowState.Minimized;
            this.Opacity = 0;
            this.Size = new Size(1, 1);
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(-2000, -2000);
            this.Text = "SessionWatcher";
        }

        private void InitializeTrayIcon()
        {
            _trayIcon = new NotifyIcon
            {
                Icon = SystemIcons.Application,
                Text = "Session Watcher",
                Visible = false // true для отладки
            };

            var menu = new ContextMenuStrip();
            menu.Items.Add("Статус", null, (s, e) => ShowStatus());
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("Выход (отладка)", null, (s, e) => ForceClose());
            _trayIcon.ContextMenuStrip = menu;
        }

        private async Task InitializeAsync()
        {
            Logger.Log("InitializeAsync: начало...");

            SystemEvents.SessionEnding += OnSessionEnding;
            SystemEvents.SessionSwitch += OnSessionSwitch;
            SystemEvents.PowerModeChanged += OnPowerModeChanged;

            Logger.Log("InitializeAsync: создаю SessionManager...");
            _sessionManager = new SessionManager();
            _sessionManager.StatusChanged += status =>
            {
                try
                {
                    if (_trayIcon != null)
                    {
                        string text = $"SessionWatcher: {status}";
                        if (text.Length > 63) text = text.Substring(0, 63);
                        _trayIcon.Text = text;
                    }
                }
                catch { }
            };

            Logger.Log("InitializeAsync: запускаю StartAsync...");
            await _sessionManager.StartAsync();

            Logger.Log("HiddenForm инициализирована, мониторинг запущен");
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_QUERYENDSESSION:
                    Logger.Log("WM_QUERYENDSESSION");
                    SafeCloseSession("ЗАВЕРШЁН");
                    m.Result = (IntPtr)1;
                    return;

                case WM_ENDSESSION:
                    Logger.Log($"WM_ENDSESSION wParam={m.WParam}");
                    if (m.WParam != IntPtr.Zero)
                    {
                        SafeCloseSession("ЗАВЕРШЁН");
                    }
                    break;

                case WM_POWERBROADCAST:
                    int pwr = m.WParam.ToInt32();
                    if (pwr == PBT_APMSUSPEND)
                        Logger.Log("Система → сон");
                    else if (pwr == PBT_APMRESUMESUSPEND)
                        Logger.Log("Система → пробуждение");
                    break;
            }

            base.WndProc(ref m);
        }

        private void OnSessionEnding(object sender, SessionEndingEventArgs e)
        {
            Logger.Log($"SessionEnding: {e.Reason}");
            SafeCloseSession("ЗАВЕРШЁН");
        }

        private void OnSessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            Logger.Log($"SessionSwitch: {e.Reason}");

            switch (e.Reason)
            {
                case SessionSwitchReason.SessionLock:
                    Logger.Log("Сессия заблокирована (Win+L)");
                    break;
                case SessionSwitchReason.SessionUnlock:
                    Logger.Log("Сессия разблокирована");
                    break;
                case SessionSwitchReason.SessionLogoff:
                    Logger.Log("Logoff");
                    SafeCloseSession("ЗАВЕРШЁН");
                    break;
            }
        }

        private void OnPowerModeChanged(object sender, PowerModeChangedEventArgs e)
        {
            Logger.Log($"PowerMode: {e.Mode}");
        }

        private void SafeCloseSession(string status)
        {
            if (_isClosing) return;
            _isClosing = true;

            try
            {
                _sessionManager?.CloseSession(status);
            }
            catch (Exception ex)
            {
                Logger.LogError("Ошибка закрытия сессии", ex);
            }
        }

        private void ShowStatus()
        {
            MessageBox.Show(
                "Session Watcher работает.\nМониторинг активной сессии.",
                "Статус", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ForceClose()
        {
            if (MessageBox.Show(
                "Принудительное закрытие?\nСессия будет АВАРИЙНОЙ!",
                "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                SafeCloseSession("АВАРИЙНЫЙ");
                Application.Exit();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Logger.Log($"FormClosing: {e.CloseReason}");

            if (e.CloseReason == CloseReason.WindowsShutDown ||
                e.CloseReason == CloseReason.TaskManagerClosing)
            {
                SafeCloseSession("ЗАВЕРШЁН");
            }

            SystemEvents.SessionEnding -= OnSessionEnding;
            SystemEvents.SessionSwitch -= OnSessionSwitch;
            SystemEvents.PowerModeChanged -= OnPowerModeChanged;

            _sessionManager?.Dispose();
            _trayIcon?.Dispose();

            base.OnFormClosing(e);
        }

        private bool _initialized = false;

        protected override void SetVisibleCore(bool value)
        {
            if (!this.IsHandleCreated)
            {
                this.CreateHandle();
                value = false;
            }
            base.SetVisibleCore(value);

            if (!_initialized)
            {
                _initialized = true;
                Logger.Log("SetVisibleCore: первый вызов, запускаю инициализацию...");
                BeginInvoke(new Action(async () =>
                {
                    try
                    {
                        await InitializeAsync();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError("InitializeAsync ИСКЛЮЧЕНИЕ", ex);
                    }
                }));
            }
        }
    }
}
