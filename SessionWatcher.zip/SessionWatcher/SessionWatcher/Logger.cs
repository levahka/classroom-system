﻿using System;
using System.Configuration;
using System.IO;
using System.Text;

namespace SessionWatcher
{
    /// <summary>
    /// Простой потокобезопасный логгер
    /// </summary>
    public static class Logger
    {
        private static readonly string LogPath;
        private static readonly object LockObj = new object();

        static Logger()
        {
            string folder = ConfigurationManager.AppSettings["LogFolder"] ?? @"C:\Program Fiiles\ClassroomSystem\logs";
            LogPath = Path.Combine(folder, "watcher_debug.log");

            try { Directory.CreateDirectory(folder); }
            catch { }
        }

        public static void Log(string message)
        {
            try
            {
                lock (LockObj)
                {
                    string line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {message}";
                    File.AppendAllText(LogPath, line + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch { }
        }

        public static void LogError(string message, Exception ex)
        {
            Log($"ОШИБКА: {message} — {ex.Message}");
            if (ex.StackTrace != null)
                Log($"  StackTrace: {ex.StackTrace}");
            if (ex.InnerException != null)
                Log($"  Inner: {ex.InnerException.Message}");
        }
    }
}
