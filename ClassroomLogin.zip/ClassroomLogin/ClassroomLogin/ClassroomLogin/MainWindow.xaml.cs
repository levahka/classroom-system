﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Web.Script.Serialization; // для JSON-сериализации

namespace ClassroomLogin
{
    public partial class MainWindow : Window
    {
        #region Constants & Fields

        static readonly string LogFolder = @"C:\Program Files\ClassroomSystem\logs";
        static readonly string LogPath = Path.Combine(LogFolder, "journal.csv");
        static readonly string SessionFile = Path.Combine(LogFolder, "current_session.txt");
        static readonly string DebugLog = Path.Combine(LogFolder, "debug_login.log");
        static readonly string LockFile = Path.Combine(LogFolder, "login.lock");
        static readonly string CacheFile = Path.Combine(LogFolder, "students_cache.json");

        private string _sessionId = "";
        private DateTime _loginTime;
        private bool _isLoggedIn = false;
        private bool _isDatabaseConnected = false;
        private bool _isWorkingFromCache = false;

        // Данные из БД
        private Dictionary<string, List<string>> _groupStudents = new Dictionary<string, List<string>>();

        // Для блокировки клавиатуры
        private IntPtr _keyboardHookId = IntPtr.Zero;
        private LowLevelKeyboardProc _keyboardProc;

        // Таймеры защиты
        private System.Windows.Threading.DispatcherTimer _protectionTimer;
        private System.Windows.Threading.DispatcherTimer _watchdogTimer;
        private System.Windows.Threading.DispatcherTimer _dbRefreshTimer;

        // Для блокировки системного меню
        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;

        #endregion

        #region Win32 API

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool BlockInput(bool fBlockIt);

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern bool EnableWindow(IntPtr hWnd, bool bEnable);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetProcessShutdownParameters(uint dwLevel, uint dwFlags);

        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_SYSKEYDOWN = 0x0104;

        #endregion

        #region Constructor & Initialization

        public MainWindow()
        {
            InitializeComponent();

            SystemEvents.SessionEnding += SystemEvents_SessionEnding;
            SystemEvents.SessionSwitch += SystemEvents_SessionSwitch;

            try { SetProcessShutdownParameters(0x3FF, 0); } catch { }
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                Directory.CreateDirectory(LogFolder);
                Log("=== MainWindow загружен ===");

                if (!AcquireLock())
                {
                    Log("Другой экземпляр уже запущен (файловый лок)");
                    _isLoggedIn = true;
                    this.Close();
                    return;
                }

                CleanupOldSession();

                // Создаём CSV с новым столбцом для проблем
                if (!File.Exists(LogPath))
                {
                    File.WriteAllText(LogPath,
                        "ID;Дата;Группа;Фамилия;Компьютер;Время входа;Время выхода;Длительность (мин);Статус;Проблемы с ПК\n",
                        Encoding.UTF8);
                    Log("Создан новый journal.csv");
                }
                else
                {
                    EnsureProblemColumnExists();
                }

                ApplyAllProtections();

                txtComputerName.Text = $"Компьютер: {Environment.MachineName}";

                // Асинхронно пробуем подключиться к БД
                await TryConnectToDatabaseAsync();

                // Запускаем фоновое обновление БД каждые 60 секунд
                StartDbRefreshTimer();

                // Устанавливаем фокус на нужный элемент
                if (_isDatabaseConnected || _isWorkingFromCache)
                    cmbGroup.Focus();
                else
                    txtGroup.Focus();
            }
            catch (Exception ex)
            {
                Log($"ОШИБКА Window_Loaded: {ex.Message}");
            }
        }

        private void EnsureProblemColumnExists()
        {
            try
            {
                var lines = File.ReadAllLines(LogPath, Encoding.UTF8).ToList();
                if (lines.Count > 0)
                {
                    var headers = lines[0].Split(';');
                    if (headers.Length == 9)
                    {
                        lines[0] += ";Проблемы с ПК";
                        for (int i = 1; i < lines.Count; i++)
                        {
                            lines[i] += ";";
                        }
                        File.WriteAllLines(LogPath, lines, Encoding.UTF8);
                        Log("Добавлен столбец 'Проблемы с ПК'");
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"EnsureProblemColumnExists ошибка: {ex.Message}");
            }
        }

        #endregion

        #region Cache (JSON)

        private void SaveCacheToFile()
        {
            try
            {
                var serializer = new JavaScriptSerializer();
                string json = serializer.Serialize(_groupStudents);
                File.WriteAllText(CacheFile, json, Encoding.UTF8);
                Log($"Кеш сохранён: {_groupStudents.Count} групп");
            }
            catch (Exception ex)
            {
                Log($"SaveCacheToFile ошибка: {ex.Message}");
            }
        }

        private bool LoadCacheFromFile()
        {
            try
            {
                if (!File.Exists(CacheFile))
                {
                    Log("Кеш-файл не найден");
                    return false;
                }

                string json = File.ReadAllText(CacheFile, Encoding.UTF8);
                var serializer = new JavaScriptSerializer();
                var data = serializer.Deserialize<Dictionary<string, List<string>>>(json);

                if (data != null && data.Count > 0)
                {
                    _groupStudents = data;
                    Log($"Кеш загружен: {_groupStudents.Count} групп, {_groupStudents.Values.Sum(v => v.Count)} студентов");
                    return true;
                }

                Log("Кеш пуст");
                return false;
            }
            catch (Exception ex)
            {
                Log($"LoadCacheFromFile ошибка: {ex.Message}");
                return false;
            }
        }

        #endregion

        #region Database Connection

        private string GetConnectionString()
        {
            try
            {
                string server = ConfigurationManager.AppSettings["MySqlServer"] ?? "MySQL-8.4";
                string port = ConfigurationManager.AppSettings["MySqlPort"] ?? "3306";
                string database = ConfigurationManager.AppSettings["MySqlDatabase"] ?? "classroom_db";
                string user = ConfigurationManager.AppSettings["MySqlUser"] ?? "classroom_user";
                string password = ConfigurationManager.AppSettings["MySqlPassword"] ?? "";
                string timeout = ConfigurationManager.AppSettings["MySqlConnectionTimeout"] ?? "5";

                return $"Server={server};Port={port};Database={database};Uid={user};Pwd={password};" +
                       $"Connection Timeout={timeout};CharSet=utf8;";
            }
            catch (Exception ex)
            {
                Log($"GetConnectionString ошибка: {ex.Message}");
                return null;
            }
        }

        private async Task TryConnectToDatabaseAsync()
        {
            UpdateDbStatus("🔄", "Подключение к базе данных...", "#3498DB");

            try
            {
                string connectionString = GetConnectionString();
                if (string.IsNullOrEmpty(connectionString))
                {
                    throw new Exception("Не удалось получить строку подключения");
                }

                var newData = new Dictionary<string, List<string>>();

                await Task.Run(() =>
                {
                    using (var connection = new MySqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "SELECT group_name, surname FROM students ORDER BY group_name, surname";
                        using (var command = new MySqlCommand(query, connection))
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string groupName = reader.GetString("group_name");
                                string surname = reader.GetString("surname");

                                if (!newData.ContainsKey(groupName))
                                {
                                    newData[groupName] = new List<string>();
                                }
                                newData[groupName].Add(surname);
                            }
                        }
                    }
                });

                if (newData.Count > 0)
                {
                    _groupStudents = newData;
                    _isDatabaseConnected = true;
                    _isWorkingFromCache = false;

                    // Сохраняем кеш
                    SaveCacheToFile();

                    // Переключаем интерфейс на ComboBox
                    Dispatcher.Invoke(() =>
                    {
                        SwitchToComboBoxMode();
                    });

                    UpdateDbStatus("✅", $"База данных подключена ({_groupStudents.Count} групп)", "#27AE60");
                    Log($"БД подключена: {_groupStudents.Count} групп, {_groupStudents.Values.Sum(v => v.Count)} студентов");
                }
                else
                {
                    throw new Exception("Данные не найдены в базе");
                }
            }
            catch (Exception ex)
            {
                Log($"Ошибка подключения к БД: {ex.Message}");
                _isDatabaseConnected = false;

                // Пробуем загрузить из кеша
                if (LoadCacheFromFile())
                {
                    _isWorkingFromCache = true;

                    Dispatcher.Invoke(() =>
                    {
                        SwitchToComboBoxMode();
                    });

                    UpdateDbStatus("⚠️", $"Работа из кеша (БД недоступна) — {_groupStudents.Count} групп", "#E67E22");
                }
                else
                {
                    ShowManualInput($"БД недоступна, кеш отсутствует");
                }
            }
        }

        /// <summary>
        /// Переключает UI на режим ComboBox (данные из БД или кеша)
        /// </summary>
        private void SwitchToComboBoxMode()
        {
            txtGroup.Visibility = Visibility.Collapsed;
            txtSurname.Visibility = Visibility.Collapsed;
            cmbGroup.Visibility = Visibility.Visible;
            cmbSurname.Visibility = Visibility.Visible;

            // Сохраняем текущий выбор
            string selectedGroup = cmbGroup.SelectedItem?.ToString();

            cmbGroup.ItemsSource = _groupStudents.Keys.OrderBy(g => g).ToList();

            // Восстанавливаем выбор если группа осталась
            if (!string.IsNullOrEmpty(selectedGroup) && _groupStudents.ContainsKey(selectedGroup))
            {
                cmbGroup.SelectedItem = selectedGroup;
            }

            cmbGroup.IsEnabled = true;
            cmbGroup.IsEditable = false;
            cmbSurname.IsEnabled = true;
            cmbSurname.IsEditable = false;
            btnLogin.IsEnabled = true;
        }

        private void ShowManualInput(string reason)
        {
            _isDatabaseConnected = false;
            _isWorkingFromCache = false;

            Dispatcher.Invoke(() =>
            {
                txtGroup.Visibility = Visibility.Visible;
                txtSurname.Visibility = Visibility.Visible;
                cmbGroup.Visibility = Visibility.Collapsed;
                cmbSurname.Visibility = Visibility.Collapsed;

                txtGroup.IsEnabled = true;
                txtSurname.IsEnabled = true;
                btnLogin.IsEnabled = true;
            });

            UpdateDbStatus("⚠️", "Ручной ввод (БД и кеш недоступны)", "#E67E22");
        }

        private void UpdateDbStatus(string icon, string text, string color)
        {
            Dispatcher.Invoke(() =>
            {
                txtDbStatusIcon.Text = icon;
                txtDbStatus.Text = text;

                var brush = new BrushConverter().ConvertFromString(color) as SolidColorBrush;
                txtDbStatus.Foreground = brush;

                if (color == "#27AE60")
                    borderDbStatus.Background = new SolidColorBrush(Color.FromRgb(232, 246, 243));
                else if (color == "#E67E22")
                    borderDbStatus.Background = new SolidColorBrush(Color.FromRgb(253, 242, 233));
                else
                    borderDbStatus.Background = new SolidColorBrush(Color.FromRgb(235, 245, 251));
            });
        }

        /// <summary>
        /// Фоновое обновление: каждые 60 сек пытается переподключиться к БД
        /// </summary>
        private void StartDbRefreshTimer()
        {
            _dbRefreshTimer = new System.Windows.Threading.DispatcherTimer();
            _dbRefreshTimer.Interval = TimeSpan.FromSeconds(60);
            _dbRefreshTimer.Tick += async (s, e) =>
            {
                if (!_isDatabaseConnected && !_isLoggedIn)
                {
                    Log("Фоновое обновление: попытка переподключения к БД...");
                    await TryConnectToDatabaseAsync();
                }
            };
            _dbRefreshTimer.Start();
            Log("Таймер фонового обновления БД запущен (60 сек)");
        }

        private void CmbGroup_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (cmbGroup.SelectedItem != null)
            {
                string selectedGroup = cmbGroup.SelectedItem.ToString();

                bool isSchool = selectedGroup.IndexOf("школа", StringComparison.OrdinalIgnoreCase) >= 0;

                if (isSchool)
                {
                    // Для школы — ручной ввод фамилии
                    cmbSurname.IsEditable = true;
                    cmbSurname.ItemsSource = null;
                    cmbSurname.Text = "";
                    Log("Выбрана группа 'Школа' — разрешён ручной ввод фамилии");
                }
                else if (_groupStudents.ContainsKey(selectedGroup))
                {
                    cmbSurname.IsEditable = false;
                    cmbSurname.ItemsSource = _groupStudents[selectedGroup].OrderBy(s => s).ToList();
                    cmbSurname.SelectedIndex = -1;
                    cmbSurname.Text = "";
                }
            }
        }

        #endregion

        #region Computer Status UI

        private void RbComputerStatus_Checked(object sender, RoutedEventArgs e)
        {
            if (panelProblemDescription == null) return;

            if (rbComputerProblem.IsChecked == true)
            {
                panelProblemDescription.Visibility = Visibility.Visible;
                txtProblemDescription.Focus();
            }
            else
            {
                panelProblemDescription.Visibility = Visibility.Collapsed;
                txtProblemDescription.Text = "";
            }
        }

        private void QuickProblem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button button)
            {
                string problem = button.Tag?.ToString() ?? "";
                if (!string.IsNullOrEmpty(txtProblemDescription.Text))
                {
                    txtProblemDescription.Text += "; " + problem;
                }
                else
                {
                    txtProblemDescription.Text = problem;
                }
            }
        }

        private string GetComputerProblemText()
        {
            if (rbComputerOk.IsChecked == true)
            {
                return "OK";
            }
            else
            {
                string problem = txtProblemDescription.Text.Trim();
                if (string.IsNullOrEmpty(problem))
                {
                    return "Проблема не описана";
                }
                return problem.Replace(";", ",").Replace("\n", " ").Replace("\r", "");
            }
        }

        #endregion

        #region Protection Methods

        private void ApplyAllProtections()
        {
            DisableSystemMenu();
            InstallKeyboardHook();
            BlockTaskManager();
            HideTaskbar();
            StartProtectionTimer();
            StartWatchdog();
            StartBackgroundProtection();
            Log("Все защиты применены");
        }

        private void DisableSystemMenu()
        {
            try
            {
                var hwnd = new WindowInteropHelper(this).Handle;
                if (hwnd != IntPtr.Zero)
                {
                    int currentStyle = GetWindowLong(hwnd, GWL_STYLE);
                    SetWindowLong(hwnd, GWL_STYLE, currentStyle & ~WS_SYSMENU);
                }
            }
            catch (Exception ex)
            {
                Log($"DisableSystemMenu ошибка: {ex.Message}");
            }
        }

        private void InstallKeyboardHook()
        {
            try
            {
                _keyboardProc = KeyboardHookCallback;
                using (Process curProcess = Process.GetCurrentProcess())
                using (ProcessModule curModule = curProcess.MainModule)
                {
                    _keyboardHookId = SetWindowsHookEx(WH_KEYBOARD_LL, _keyboardProc,
                        GetModuleHandle(curModule.ModuleName), 0);
                }

                if (_keyboardHookId != IntPtr.Zero)
                    Log("Клавиатурный хук установлен");
                else
                    Log("ОШИБКА установки клавиатурного хука");
            }
            catch (Exception ex)
            {
                Log($"InstallKeyboardHook ошибка: {ex.Message}");
            }
        }

        private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (_isLoggedIn)
                return CallNextHookEx(_keyboardHookId, nCode, wParam, lParam);

            if (nCode >= 0)
            {
                int vkCode = Marshal.ReadInt32(lParam);
                bool blockKey = false;

                bool ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
                bool alt = (Keyboard.Modifiers & ModifierKeys.Alt) != 0;

                switch (vkCode)
                {
                    case 0x5B:
                    case 0x5C:
                        blockKey = true;
                        break;
                    case 0x1B:
                        if (ctrl || alt) blockKey = true;
                        break;
                    case 0x09:
                        if (alt) blockKey = true;
                        break;
                    case 0x73:
                        if (alt) blockKey = true;
                        break;
                    case 0x2E:
                        if (ctrl && alt) blockKey = true;
                        break;
                }

                if (Keyboard.IsKeyDown(Key.LWin) || Keyboard.IsKeyDown(Key.RWin))
                {
                    blockKey = true;
                }

                if (blockKey)
                {
                    Log($"Заблокирована клавиша: {vkCode}");
                    return (IntPtr)1;
                }
            }

            return CallNextHookEx(_keyboardHookId, nCode, wParam, lParam);
        }

        private void BlockTaskManager()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Policies\System"))
                {
                    key?.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                }

                try
                {
                    using (RegistryKey key = Registry.LocalMachine.CreateSubKey(
                        @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"))
                    {
                        key?.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                    }
                }
                catch { }

                Log("TaskManager заблокирован");
            }
            catch (Exception ex)
            {
                Log($"BlockTaskManager ошибка: {ex.Message}");
            }
        }

        private void HideTaskbar()
        {
            try
            {
                IntPtr taskbar = FindWindow("Shell_TrayWnd", null);
                if (taskbar != IntPtr.Zero)
                {
                    ShowWindow(taskbar, 0);
                    EnableWindow(taskbar, false);
                }

                IntPtr startButton = FindWindow("Button", "Start");
                if (startButton != IntPtr.Zero)
                {
                    ShowWindow(startButton, 0);
                }

                Log("Панель задач скрыта");
            }
            catch (Exception ex)
            {
                Log($"HideTaskbar ошибка: {ex.Message}");
            }
        }

        private void ShowTaskbar()
        {
            try
            {
                IntPtr taskbar = FindWindow("Shell_TrayWnd", null);
                if (taskbar != IntPtr.Zero)
                {
                    EnableWindow(taskbar, true);
                    ShowWindow(taskbar, 5);
                }
            }
            catch { }
        }

        private void StartProtectionTimer()
        {
            _protectionTimer = new System.Windows.Threading.DispatcherTimer();
            _protectionTimer.Interval = TimeSpan.FromMilliseconds(50);
            _protectionTimer.Tick += (s, e) =>
            {
                if (!_isLoggedIn)
                {
                    if (GetForegroundWindow() != new WindowInteropHelper(this).Handle)
                    {
                        this.Activate();
                        this.Focus();
                        SetForegroundWindow(new WindowInteropHelper(this).Handle);
                    }

                    if (this.WindowState != WindowState.Maximized)
                        this.WindowState = WindowState.Maximized;

                    if (!this.Topmost)
                        this.Topmost = true;

                    KillDangerousProcesses();
                }
            };
            _protectionTimer.Start();
            Log("Protection timer запущен");
        }

        private void KillDangerousProcesses()
        {
            string[] dangerousProcesses = { "taskmgr", "cmd", "powershell", "regedit", "mmc" };

            foreach (string procName in dangerousProcesses)
            {
                try
                {
                    foreach (var proc in Process.GetProcessesByName(procName))
                    {
                        proc.Kill();
                        Log($"Убит процесс: {procName}");
                    }
                }
                catch { }
            }
        }

        private void StartWatchdog()
        {
            _watchdogTimer = new System.Windows.Threading.DispatcherTimer();
            _watchdogTimer.Interval = TimeSpan.FromSeconds(1);
            _watchdogTimer.Tick += (s, e) =>
            {
                if (!_isLoggedIn)
                {
                    try
                    {
                        File.WriteAllText(LockFile, DateTime.Now.ToString("o"));
                    }
                    catch { }

                    HideTaskbar();
                }
            };
            _watchdogTimer.Start();
        }

        private void StartBackgroundProtection()
        {
            Task.Run(() =>
            {
                while (!_isLoggedIn)
                {
                    try
                    {
                        string[] dangerous = { "taskmgr", "ProcessHacker", "procexp", "procexp64" };
                        foreach (string name in dangerous)
                        {
                            foreach (var p in Process.GetProcessesByName(name))
                            {
                                try { p.Kill(); } catch { }
                            }
                        }

                        Thread.Sleep(500);
                    }
                    catch { }
                }
            });
        }

        #endregion

        #region Lock File (Singleton)

        private FileStream _lockStream;

        private bool AcquireLock()
        {
            try
            {
                _lockStream = new FileStream(LockFile, FileMode.OpenOrCreate,
                    FileAccess.ReadWrite, FileShare.None);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void ReleaseLock()
        {
            try
            {
                _lockStream?.Close();
                _lockStream?.Dispose();
                if (File.Exists(LockFile))
                    File.Delete(LockFile);
            }
            catch { }
        }

        #endregion

        #region Event Handlers

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (!_isLoggedIn)
            {
                if (e.Key == Key.System && e.SystemKey == Key.F4)
                    e.Handled = true;
                if (e.Key == Key.LWin || e.Key == Key.RWin)
                    e.Handled = true;
                if (e.Key == Key.Escape &&
                    (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) ||
                     Keyboard.Modifiers.HasFlag(ModifierKeys.Alt)))
                    e.Handled = true;
                if (e.Key == Key.Tab && Keyboard.Modifiers.HasFlag(ModifierKeys.Alt))
                    e.Handled = true;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.System && e.SystemKey == Key.F4)
                e.Handled = true;

            if (e.Key == Key.Enter)
                BtnLogin_Click(sender, e);
        }

        private void Window_Deactivated(object sender, EventArgs e)
        {
            if (!_isLoggedIn)
            {
                this.Activate();
                this.Focus();
                SetForegroundWindow(new WindowInteropHelper(this).Handle);
            }
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            if (!_isLoggedIn && this.WindowState != WindowState.Maximized)
                this.WindowState = WindowState.Maximized;
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            if (!_isLoggedIn)
            {
                e.Cancel = true;
                Log("Попытка закрытия заблокирована");
            }
        }

        private void SystemEvents_SessionEnding(object sender, SessionEndingEventArgs e)
        {
            Log($"SessionEnding: {e.Reason}");

            if (!_isLoggedIn)
                e.Cancel = true;
            else
                WriteLogoutTime();
        }

        private void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            Log($"SessionSwitch: {e.Reason}");

            if (!_isLoggedIn && e.Reason == SessionSwitchReason.SessionLock)
                this.Activate();
        }

        #endregion

        #region Login Logic

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string group;
            string surname;

            if (_isDatabaseConnected || _isWorkingFromCache)
            {
                group = cmbGroup.Text?.Trim() ?? "";
                surname = cmbSurname.Text?.Trim() ?? "";
            }
            else
            {
                group = txtGroup.Text.Trim();
                surname = txtSurname.Text.Trim();
            }

            // Админский вход
            if (group.ToLower() == "admin" && surname == "exit2024")
            {
                Log("Админский вход");
                _isLoggedIn = true;
                CleanupAndClose();
                return;
            }

            // Валидация
            if (string.IsNullOrEmpty(group))
            {
                ShowError("Выберите группу!");
                if (_isDatabaseConnected || _isWorkingFromCache)
                    cmbGroup.Focus();
                else
                    txtGroup.Focus();
                return;
            }
            if (string.IsNullOrEmpty(surname))
            {
                ShowError("Введите фамилию!");
                if (_isDatabaseConnected || _isWorkingFromCache)
                    cmbSurname.Focus();
                else
                    txtSurname.Focus();
                return;
            }

            if (group.Length < 2)
            {
                ShowError("Номер группы слишком короткий!");
                return;
            }
            if (surname.Length < 2)
            {
                ShowError("Фамилия слишком короткая!");
                return;
            }

            if (rbComputerProblem.IsChecked == true && string.IsNullOrWhiteSpace(txtProblemDescription.Text))
            {
                ShowError("Пожалуйста, опишите проблему с компьютером!");
                txtProblemDescription.Focus();
                return;
            }

            _sessionId = DateTime.Now.ToString("yyyyMMddHHmmss") + "_" + Environment.MachineName;
            _loginTime = DateTime.Now;

            string computerStatus = GetComputerProblemText();
            Log($"Логин: {group} / {surname} / SessionID: {_sessionId} / Статус ПК: {computerStatus}");

            WriteLoginToJournal(group, surname, computerStatus);
            SaveSessionFile();

            _isLoggedIn = true;

            bool watcherStarted = StartBackgroundWatcher();
            Log($"SessionWatcher запущен: {watcherStarted}");

            CleanupAndClose();
        }

        private void ShowError(string text)
        {
            borderError.Visibility = Visibility.Visible;
            txtError.Text = text;
        }

        #endregion

        #region Journal & Session

        private void WriteLoginToJournal(string group, string surname, string computerStatus)
        {
            try
            {
                string logEntry = string.Join(";",
                    _sessionId,
                    _loginTime.ToString("yyyy-MM-dd"),
                    group,
                    surname,
                    Environment.MachineName,
                    _loginTime.ToString("HH:mm:ss"),
                    "-",
                    "0",
                    "АКТИВЕН",
                    computerStatus
                ) + "\n";

                File.AppendAllText(LogPath, logEntry, Encoding.UTF8);
                Log("Запись в журнал добавлена");
            }
            catch (Exception ex)
            {
                Log($"ОШИБКА WriteLoginToJournal: {ex.Message}");
            }
        }

        private void SaveSessionFile()
        {
            try
            {
                string data = $"{_sessionId}|{_loginTime:yyyy-MM-dd HH:mm:ss}";
                File.WriteAllText(SessionFile, data);
                Log($"SessionFile сохранён");
            }
            catch (Exception ex)
            {
                Log($"ОШИБКА SaveSessionFile: {ex.Message}");
            }
        }

        private void CleanupOldSession()
        {
            try
            {
                if (File.Exists(SessionFile))
                {
                    Log("Найден старый SessionFile — помечаем как АВАРИЙНЫЙ");

                    string sessionData = File.ReadAllText(SessionFile, Encoding.UTF8);
                    string[] parts = sessionData.Split('|');

                    if (parts.Length >= 2 && File.Exists(LogPath))
                    {
                        string oldSessionId = parts[0].Trim();
                        var lines = File.ReadAllLines(LogPath, Encoding.UTF8).ToList();

                        bool found = false;

                        for (int i = 0; i < lines.Count; i++)
                        {
                            if (lines[i].StartsWith(oldSessionId + ";"))
                            {
                                var columns = lines[i].Split(';');

                                if (columns.Length >= 9 && columns[8].Trim() == "АКТИВЕН")
                                {
                                    columns[8] = "АВАРИЙНЫЙ";
                                    lines[i] = string.Join(";", columns);
                                    Log($"Сессия {oldSessionId} помечена как АВАРИЙНЫЙ");
                                    found = true;
                                }
                                break;
                            }
                        }

                        if (!found)
                            Log($"Сессия {oldSessionId} не найдена или не была АКТИВНА");

                        File.WriteAllLines(LogPath, lines, Encoding.UTF8);
                    }

                    File.Delete(SessionFile);
                    Log("SessionFile удалён");
                }
            }
            catch (Exception ex)
            {
                Log($"ОШИБКА CleanupOldSession: {ex.Message}");
            }
        }

        private static void WriteLogoutTime()
        {
            try
            {
                if (!File.Exists(SessionFile) || !File.Exists(LogPath))
                    return;

                string sessionData = File.ReadAllText(SessionFile);
                string[] parts = sessionData.Split('|');
                if (parts.Length < 2) return;

                string sessionId = parts[0];
                DateTime loginTime = DateTime.Parse(parts[1]);
                DateTime logoutTime = DateTime.Now;
                int duration = (int)(logoutTime - loginTime).TotalMinutes;

                var lines = File.ReadAllLines(LogPath, Encoding.UTF8).ToList();

                for (int i = 0; i < lines.Count; i++)
                {
                    if (lines[i].StartsWith(sessionId + ";"))
                    {
                        var columns = lines[i].Split(';');
                        if (columns.Length >= 9)
                        {
                            columns[6] = logoutTime.ToString("HH:mm:ss");
                            columns[7] = duration.ToString();
                            columns[8] = "ЗАВЕРШЁН";
                            lines[i] = string.Join(";", columns);
                        }
                        break;
                    }
                }

                File.WriteAllLines(LogPath, lines, Encoding.UTF8);
                File.Delete(SessionFile);
            }
            catch { }
        }

        #endregion

        #region Watcher

        private bool StartBackgroundWatcher()
        {
            string watcherPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "SessionWatcher.exe");

            if (!File.Exists(watcherPath))
            {
                Log("ОШИБКА: SessionWatcher.exe не найден!");
                return false;
            }

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = watcherPath,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    CreateNoWindow = true,
                    UseShellExecute = false
                };

                var process = Process.Start(psi);
                if (process != null)
                {
                    Log($"SessionWatcher запущен, PID: {process.Id}");
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                Log($"ОШИБКА запуска SessionWatcher: {ex.Message}");
                return false;
            }
        }

        #endregion

        #region Cleanup

        private void CleanupAndClose()
        {
            try
            {
                _protectionTimer?.Stop();
                _watchdogTimer?.Stop();
                _dbRefreshTimer?.Stop();

                if (_keyboardHookId != IntPtr.Zero)
                {
                    UnhookWindowsHookEx(_keyboardHookId);
                    _keyboardHookId = IntPtr.Zero;
                }

                UnblockTaskManager();
                ShowTaskbar();
                ReleaseLock();

                SystemEvents.SessionEnding -= SystemEvents_SessionEnding;
                SystemEvents.SessionSwitch -= SystemEvents_SessionSwitch;

                Log("Все защиты сняты, окно закрывается");
            }
            catch (Exception ex)
            {
                Log($"CleanupAndClose ошибка: {ex.Message}");
            }

            this.Close();
        }

        private void UnblockTaskManager()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Policies\System", true))
                {
                    key?.DeleteValue("DisableTaskMgr", false);
                }

                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer", true))
                {
                    key?.DeleteValue("NoWinKeys", false);
                }
            }
            catch { }
        }

        #endregion

        #region Logging

        private static void Log(string message)
        {
            try
            {
                string line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {message}";
                File.AppendAllText(DebugLog, line + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        #endregion
    }
}
