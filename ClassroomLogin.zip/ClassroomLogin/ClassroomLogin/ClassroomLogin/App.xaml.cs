﻿using System;
using System.Threading;
using System.Windows;

namespace ClassroomLogin
{
    public partial class App : Application
    {
        private static Mutex _mutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            // Mutex-синглтон: если другой экземпляр уже запущен — тихо выходим
            bool createdNew;
            _mutex = new Mutex(true, @"Global\ClassroomLoginMutex", out createdNew);

            if (!createdNew)
            {
                // Другой экземпляр уже работает — выходим без ошибок
                Environment.Exit(0);
                return;
            }

            base.OnStartup(e);

            // Обработка необработанных исключений
            this.DispatcherUnhandledException += (s, args) =>
            {
                args.Handled = true; // Не падаем
            };
        }

        protected override void OnExit(ExitEventArgs e)
        {
            try
            {
                _mutex?.ReleaseMutex();
                _mutex?.Dispose();
            }
            catch { }

            base.OnExit(e);
        }
    }
}
